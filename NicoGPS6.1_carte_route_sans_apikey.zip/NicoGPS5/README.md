# NicoGPS 6.1 – recherche avec sélection

Cette version conserve le GPS, la carte, le guidage et Android Auto de la base 6.0.

Correction principale : la recherche affiche plusieurs destinations et attend que l'utilisateur sélectionne explicitement un résultat avant de calculer l'itinéraire.

## GitHub Actions
Le workflow `build-nicogps-6.0.yml` doit être adapté au nom du ZIP source utilisé dans le dépôt si nécessaire.
