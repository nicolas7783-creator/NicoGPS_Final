package com.nicogps.app;

import android.app.Application;
import androidx.lifecycle.MutableLiveData;
import com.google.android.libraries.mapsplatform.turnbyturn.model.NavInfo;
import com.google.android.libraries.navigation.NavigationApi;

public class NicoGPSApplication extends Application {
    private final MutableLiveData<NavInfo> navInfo = new MutableLiveData<>();

    public MutableLiveData<NavInfo> getNavInfoLiveData() { return navInfo; }

    public void publishNavInfo(NavInfo info) { navInfo.postValue(info); }

    @Override public void onCreate() {
        super.onCreate();
        if (BuildConfig.MAPS_API_KEY != null && !BuildConfig.MAPS_API_KEY.isEmpty()) {
            NavigationApi.setApiKey(BuildConfig.MAPS_API_KEY);
        }
    }
}
