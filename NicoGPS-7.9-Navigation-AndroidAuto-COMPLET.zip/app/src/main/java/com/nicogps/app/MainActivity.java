package com.nicogps.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.*;
import android.view.View;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.google.android.libraries.navigation.*;
import com.google.android.libraries.navigation.SupportNavigationFragment;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.CameraPerspective;
import com.google.android.libraries.mapsplatform.turnbyturn.model.NavInfo;
import com.google.android.libraries.navigation.Navigator.RouteStatus;
import com.google.android.gms.maps.model.LatLng;
import okhttp3.*;
import com.google.gson.*;
import java.io.IOException;
import java.util.*;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {
    private Navigator navigator;
    private SupportNavigationFragment navFragment;
    private TextView status, eta, distance;
    private final OkHttpClient http = new OkHttpClient.Builder().build();
    private final ArrayList<SearchResult> results = new ArrayList<>();
    private String destinationTitle = "";
    private final Navigator.RemainingTimeOrDistanceChangedListener tripListener =
        this::updateTripInfo;

    private final ActivityResultLauncher<String[]> permissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r -> initializeNavigation());

    private static class SearchResult {
        final double lat, lon; final String title;
        SearchResult(double lat, double lon, String title) {
            this.lat=lat; this.lon=lon; this.title=title;
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status=findViewById(R.id.status);
        eta=findViewById(R.id.eta);
        distance=findViewById(R.id.distance);

        findViewById(R.id.search).setOnClickListener(v -> showSearch());
        findViewById(R.id.route_overview).setOnClickListener(v -> {
            if (navFragment != null) navFragment.showRouteOverview();
        });
        findViewById(R.id.stop).setOnClickListener(v -> stopNavigation());

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION});
        } else initializeNavigation();
    }

    private void initializeNavigation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) return;

        navFragment=(SupportNavigationFragment)getSupportFragmentManager()
                .findFragmentById(R.id.navigation_fragment);

        if (navFragment != null) {
            navFragment.setReportIncidentButtonEnabled(true);
            navFragment.setTrafficIncidentCardsEnabled(true);
            navFragment.setTrafficPromptsEnabled(true);
            navFragment.setSpeedometerEnabled(true);
            navFragment.setSpeedLimitIconEnabled(true);
            navFragment.setEtaCardEnabled(true);
            navFragment.setRecenterButtonEnabled(true);
            navFragment.getMapAsync(map -> map.followMyLocation(CameraPerspective.TILTED));
        }

        NavigationApi.getNavigator(this, new NavigationApi.NavigatorListener() {
            @Override public void onNavigatorReady(@NonNull Navigator n) {
                navigator=n;
                RoutingOptions options=new RoutingOptions();
                options.travelMode(RoutingOptions.TravelMode.DRIVING);

                navigator.addRemainingTimeOrDistanceChangedListener(30, 100, tripListener);

                navigator.addRouteChangedListener(() ->
                    runOnUiThread(() -> status.setText("Itinéraire mis à jour")));

                navigator.addReroutingListener(() ->
                    runOnUiThread(() -> status.setText("Recalcul de l'itinéraire…")));

                navigator.addArrivalListener(event ->
                    runOnUiThread(() -> {
                        status.setText("🎉 Arrivée à destination");
                        CarNavigationState.active=false;
                    }));

                status.setText("NicoGPS prêt");
            }

            @Override public void onError(@NavigationApi.ErrorCode int errorCode) {
                status.setText("Navigation indisponible : " + errorCode);
                Toast.makeText(MainActivity.this,
                        "Navigation Google : " + errorCode, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void showSearch() {
        final EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setHint("Adresse, ville ou lieu");
        new AlertDialog.Builder(this)
            .setTitle("Destination NicoGPS")
            .setView(input)
            .setPositiveButton("Rechercher", (d,w) -> {
                String q=input.getText().toString().trim();
                if(!q.isEmpty()) searchDestination(q);
            })
            .setNegativeButton("Annuler", null)
            .show();
    }

    private void searchDestination(String q) {
        status.setText("Recherche…");
        new Thread(() -> {
            ArrayList<SearchResult> found=new ArrayList<>();
            try {
                Geocoder g=new Geocoder(this, Locale.FRANCE);
                List<android.location.Address> a=g.getFromLocationName(q,5);
                if(a!=null) for(android.location.Address x:a)
                    if(x.hasLatitude() && x.hasLongitude())
                        found.add(new SearchResult(x.getLatitude(),x.getLongitude(),
                            x.getAddressLine(0)!=null?x.getAddressLine(0):q));
            } catch(Exception ignored) {}

            if(found.isEmpty()) {
                try {
                    String u="https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&countrycodes=fr&q="
                        +URLEncoder.encode(q,"UTF-8");
                    Request req=new Request.Builder().url(u)
                        .header("User-Agent","NicoGPS/7.0 contact=nicolasgps").build();
                    try(Response res=http.newCall(req).execute()) {
                        if(res.isSuccessful() && res.body()!=null) {
                            JsonArray arr=JsonParser.parseString(res.body().string()).getAsJsonArray();
                            for(JsonElement e:arr) {
                                JsonObject o=e.getAsJsonObject();
                                found.add(new SearchResult(
                                    o.get("lat").getAsDouble(), o.get("lon").getAsDouble(),
                                    o.has("display_name")?o.get("display_name").getAsString():q));
                            }
                        }
                    }
                } catch(Exception ignored) {}
            }

            runOnUiThread(() -> showResults(q,found));
        }).start();
    }

    private void showResults(String q, ArrayList<SearchResult> found) {
        if(found.isEmpty()) {
            status.setText("Destination introuvable");
            Toast.makeText(this,"Aucun résultat pour « "+q+" »",Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels=new String[found.size()];
        for(int i=0;i<found.size();i++) labels[i]=found.get(i).title;
        new AlertDialog.Builder(this)
            .setTitle("Choisir la destination")
            .setItems(labels,(d,which) -> startNavigation(found.get(which)))
            .setNegativeButton("Annuler",null).show();
    }

    private void startNavigation(SearchResult r) {
        if(navigator==null) {
            Toast.makeText(this,"Navigation Google pas encore prête",Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Waypoint wp=Waypoint.builder()
                .setLatLng(r.lat,r.lon)
                .setTitle(r.title)
                .setVehicleStopover(true)
                .build();

            destinationTitle=r.title;
            status.setText("Calcul de l’itinéraire Google…");
            CarNavigationState.destination=destinationTitle;

            RoutingOptions options=new RoutingOptions();
            options.travelMode(RoutingOptions.TravelMode.DRIVING);

            ListenableResultFuture<RouteStatus> future=navigator.setDestination(wp,options);
            future.setOnResultListener(code -> {
                runOnUiThread(() -> {
                    if(code==RouteStatus.OK) {
                        AudioGuidanceSettings audio=AudioGuidanceSettings.builder()
                            .setGuidanceMode(AudioGuidanceSettings.GuidanceMode.VOICE_ALERTS_AND_GUIDANCE)
                            .build();
                        navigator.setAudioGuidanceSettings(audio);
                        navigator.startGuidance();
                        CarNavigationState.active=true;
                        status.setText("Navigation active • "+destinationTitle);
                        updateTripInfo();
                    } else {
                        status.setText("Erreur itinéraire : "+code);
                        Toast.makeText(this,"Itinéraire Google : "+code,Toast.LENGTH_LONG).show();
                    }
                });
            });
        } catch(Exception e) {
            status.setText("Destination invalide");
        }
    }

    private void updateTripInfo() {
        if(navigator==null) return;
        try {
            TimeAndDistance td=navigator.getCurrentTimeAndDistance();
            if(td==null) return;
            long sec=td.getSeconds();
            long min=Math.max(1,Math.round(sec/60.0));
            double km=td.getMeters()/1000.0;
            eta.setText(min+" min");
            distance.setText(String.format(Locale.FRANCE,"%.1f km",km));
            CarNavigationState.etaMinutes=(int)min;
            CarNavigationState.remainingKm=km;
        } catch(Exception ignored) {}
    }

    private void stopNavigation() {
        if(navigator!=null) navigator.clearDestinations();
        CarNavigationState.active=false;
        eta.setText("-- min");
        distance.setText("-- km");
        status.setText("NicoGPS prêt");
    }

    @Override protected void onDestroy() {
        if(navigator!=null) {
            try { navigator.removeRemainingTimeOrDistanceChangedListener(tripListener); } catch(Exception ignored) {}
            if (isFinishing()) {
                try { navigator.cleanup(); } catch(Exception ignored) {}
            }
        }
        super.onDestroy();
    }
}
