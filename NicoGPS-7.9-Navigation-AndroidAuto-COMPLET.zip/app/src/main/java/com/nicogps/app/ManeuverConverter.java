package com.nicogps.app;

import com.google.android.libraries.mapsplatform.turnbyturn.model.Maneuver;

public final class ManeuverConverter {
    private ManeuverConverter() {}

    public static int toAutoType(int m) {
        switch(m) {
            case Maneuver.DEPART: return androidx.car.app.navigation.model.Maneuver.TYPE_DEPART;
            case Maneuver.DESTINATION: return androidx.car.app.navigation.model.Maneuver.TYPE_DESTINATION;
            case Maneuver.DESTINATION_LEFT: return androidx.car.app.navigation.model.Maneuver.TYPE_DESTINATION_LEFT;
            case Maneuver.DESTINATION_RIGHT: return androidx.car.app.navigation.model.Maneuver.TYPE_DESTINATION_RIGHT;
            case Maneuver.TURN_LEFT: return androidx.car.app.navigation.model.Maneuver.TYPE_TURN_NORMAL_LEFT;
            case Maneuver.TURN_RIGHT: return androidx.car.app.navigation.model.Maneuver.TYPE_TURN_NORMAL_RIGHT;
            case Maneuver.TURN_SLIGHT_LEFT: return androidx.car.app.navigation.model.Maneuver.TYPE_TURN_SLIGHT_LEFT;
            case Maneuver.TURN_SLIGHT_RIGHT: return androidx.car.app.navigation.model.Maneuver.TYPE_TURN_SLIGHT_RIGHT;
            case Maneuver.TURN_SHARP_LEFT: return androidx.car.app.navigation.model.Maneuver.TYPE_TURN_SHARP_LEFT;
            case Maneuver.TURN_SHARP_RIGHT: return androidx.car.app.navigation.model.Maneuver.TYPE_TURN_SHARP_RIGHT;
            case Maneuver.TURN_U_TURN_CLOCKWISE: return androidx.car.app.navigation.model.Maneuver.TYPE_U_TURN_RIGHT;
            case Maneuver.TURN_U_TURN_COUNTERCLOCKWISE: return androidx.car.app.navigation.model.Maneuver.TYPE_U_TURN_LEFT;
            case Maneuver.TURN_KEEP_LEFT: return androidx.car.app.navigation.model.Maneuver.TYPE_KEEP_LEFT;
            case Maneuver.TURN_KEEP_RIGHT: return androidx.car.app.navigation.model.Maneuver.TYPE_KEEP_RIGHT;
            case Maneuver.FORK_LEFT: return androidx.car.app.navigation.model.Maneuver.TYPE_FORK_LEFT;
            case Maneuver.FORK_RIGHT: return androidx.car.app.navigation.model.Maneuver.TYPE_FORK_RIGHT;
            case Maneuver.MERGE_LEFT: return androidx.car.app.navigation.model.Maneuver.TYPE_MERGE_LEFT;
            case Maneuver.MERGE_RIGHT: return androidx.car.app.navigation.model.Maneuver.TYPE_MERGE_RIGHT;
            case Maneuver.OFF_RAMP_LEFT: return androidx.car.app.navigation.model.Maneuver.TYPE_OFF_RAMP_NORMAL_LEFT;
            case Maneuver.OFF_RAMP_RIGHT: return androidx.car.app.navigation.model.Maneuver.TYPE_OFF_RAMP_NORMAL_RIGHT;
            case Maneuver.ON_RAMP_LEFT: return androidx.car.app.navigation.model.Maneuver.TYPE_ON_RAMP_NORMAL_LEFT;
            case Maneuver.ON_RAMP_RIGHT: return androidx.car.app.navigation.model.Maneuver.TYPE_ON_RAMP_NORMAL_RIGHT;
            case Maneuver.STRAIGHT: return androidx.car.app.navigation.model.Maneuver.TYPE_STRAIGHT;
            default: return androidx.car.app.navigation.model.Maneuver.TYPE_STRAIGHT;
        }
    }
}
