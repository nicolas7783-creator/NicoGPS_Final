package com.nicogps.app;

import android.app.Service;
import android.content.Intent;
import android.os.*;
import androidx.annotation.Nullable;
import com.google.android.libraries.mapsplatform.turnbyturn.TurnByTurnManager;
import com.google.android.libraries.mapsplatform.turnbyturn.model.NavInfo;

public class NavInfoReceivingService extends Service {
    private Messenger incoming;
    private TurnByTurnManager manager;
    private HandlerThread thread;

    private final class IncomingHandler extends Handler {
        IncomingHandler(Looper looper) { super(looper); }
        @Override public void handleMessage(Message msg) {
            if (TurnByTurnManager.MSG_NAV_INFO == msg.what) {
                try {
                    NavInfo info=manager.readNavInfoFromBundle(msg.getData());
                    NicoGPSApplication app=(NicoGPSApplication)getApplication();
                    app.publishNavInfo(info);
                } catch(Exception ignored) {}
            }
        }
    }

    @Override public void onCreate() {
        super.onCreate();
        manager=TurnByTurnManager.createInstance();
        thread=new HandlerThread("NicoGPS-NavInfo", Process.THREAD_PRIORITY_DEFAULT);
        thread.start();
        incoming=new Messenger(new IncomingHandler(thread.getLooper()));
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return incoming.getBinder(); }

    @Override public void onDestroy() {
        if(thread!=null) thread.quitSafely();
        super.onDestroy();
    }
}
