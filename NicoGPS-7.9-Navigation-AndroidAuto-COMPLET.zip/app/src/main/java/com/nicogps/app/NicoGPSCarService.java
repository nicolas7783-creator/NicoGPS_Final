package com.nicogps.app;

import android.app.Presentation;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.os.Bundle;
import android.view.Display;
import android.view.Surface;
import androidx.annotation.NonNull;
import androidx.car.app.*;
import androidx.car.app.model.*;
import androidx.car.app.navigation.model.NavigationTemplate;
import androidx.car.app.navigation.model.RoutingInfo;
import androidx.car.app.navigation.model.Step;
import androidx.lifecycle.Observer;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.libraries.navigation.NavigationViewForAuto;
import com.google.android.libraries.mapsplatform.turnbyturn.model.NavInfo;
import com.google.android.libraries.mapsplatform.turnbyturn.model.StepInfo;
import androidx.core.graphics.drawable.IconCompat;

public class NicoGPSCarService extends CarAppService {
    @NonNull @Override public HostValidator createHostValidator() {
        return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR;
    }

    @NonNull @Override public Session onCreateSession() {
        return new Session() {
            @NonNull @Override public Screen onCreateScreen(@NonNull Intent intent) {
                return new CarScreen(getCarContext());
            }
        };
    }

    private static class CarScreen extends Screen implements SurfaceCallback {
        private final NicoGPSApplication app;
        private NavigationViewForAuto navigationView;
        private Presentation presentation;
        private VirtualDisplay virtualDisplay;
        private GoogleMap googleMap;
        private RoutingInfo routingInfo;

        CarScreen(CarContext context) {
            super(context);
            app=(NicoGPSApplication)context.getApplicationContext();
            context.getCarService(AppManager.class).setSurfaceCallback(this);
            app.getNavInfoLiveData().observe(this, new Observer<NavInfo>() {
                @Override public void onChanged(NavInfo info) {
                    processNavInfo(info);
                }
            });
        }

        private boolean surfaceReady(SurfaceContainer s) {
            return s.getSurface()!=null && s.getDpi()!=0 && s.getWidth()!=0 && s.getHeight()!=0;
        }

        @Override public void onSurfaceAvailable(@NonNull SurfaceContainer sc) {
            if(!surfaceReady(sc)) return;
            DisplayManager dm=getCarContext().getSystemService(DisplayManager.class);
            virtualDisplay=dm.createVirtualDisplay(
                "NicoGPSAuto", sc.getWidth(), sc.getHeight(), sc.getDpi(),
                sc.getSurface(), DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY);
            presentation=new Presentation(getCarContext(), virtualDisplay.getDisplay());
            navigationView=new NavigationViewForAuto(getCarContext());
            navigationView.onCreate(null);
            navigationView.onStart();
            navigationView.onResume();
            presentation.setContentView(navigationView);
            presentation.show();
            navigationView.getMapAsync(map -> googleMap=map);
        }

        @Override public void onSurfaceDestroyed(@NonNull SurfaceContainer sc) {
            if(navigationView!=null) {
                navigationView.onPause();
                navigationView.onStop();
                navigationView.onDestroy();
                navigationView=null;
            }
            if(presentation!=null) { presentation.dismiss(); presentation=null; }
            if(virtualDisplay!=null) { virtualDisplay.release(); virtualDisplay=null; }
            googleMap=null;
        }

        @NonNull @Override public Template onGetTemplate() {
            NavigationTemplate.Builder b=new NavigationTemplate.Builder()
                .setActionStrip(new ActionStrip.Builder().build())
                .setMapActionStrip(new ActionStrip.Builder().addAction(Action.PAN).build());
            if(routingInfo!=null) b.setNavigationInfo(routingInfo);
            return b.build();
        }

        private void processNavInfo(NavInfo info) {
            if(info==null || info.getCurrentStep()==null) return;
            StepInfo s=info.getCurrentStep();
            androidx.car.app.navigation.model.Maneuver.Builder mb =
                new androidx.car.app.navigation.model.Maneuver.Builder(ManeuverConverter.toAutoType(s.getManeuver()));
            if(s.getManeuverBitmap()!=null) {
                mb.setIcon(new CarIcon.Builder(IconCompat.createWithBitmap(s.getManeuverBitmap())).build());
            }
            Step step=new Step.Builder()
                .setRoad(s.getFullRoadName()==null?"":s.getFullRoadName())
                .setCue(s.getFullInstructionText()==null?"":s.getFullInstructionText())
                .setManeuver(mb.build())
                .build();
            Integer meters=info.getDistanceToCurrentStepMeters();
            if(meters==null) meters=0;
            routingInfo=new RoutingInfo.Builder()
                .setCurrentStep(step, Distance.create(Math.max(0,meters), Distance.UNIT_METERS))
                .build();
            invalidate();
        }

        @Override public void onClick(float x,float y) {
            if(googleMap!=null) googleMap.animateCamera(CameraUpdateFactory.scrollBy(0,0));
        }
        @Override public void onScroll(float dx,float dy) {
            if(googleMap!=null) googleMap.moveCamera(CameraUpdateFactory.scrollBy(dx,dy));
        }
        @Override public void onScale(float x,float y,float scale) {
            if(googleMap!=null) googleMap.animateCamera(
                CameraUpdateFactory.zoomBy(scale-1,new Point((int)x,(int)y)));
        }
        @Override public void onFling(float dx,float dy) {}
        @Override public void onMove(float dx,float dy) {}
        @Override public void onStableAreaChanged(@NonNull android.graphics.Rect r) {}
        @Override public void onVisibleAreaChanged(@NonNull android.graphics.Rect r) {}
    }
}
