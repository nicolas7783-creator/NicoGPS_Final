# NicoGPS Navigation + Android Auto

Base source: NicoGPS 6.2.1 Google Maps, refondue autour du Google Maps Platform Navigation SDK for Android 7.9.0.

## Ce que cette version vise
- Google Navigation SDK pour la carte et le guidage détaillé
- calcul d'itinéraire Google et recalcul automatique
- guidage vocal
- ETA / distance restantes
- trafic et itinéraires alternatifs gérés par le SDK
- vitesse et limitation affichées par l'UI de navigation
- signalement d'incidents via le bouton du Navigation SDK
- Android Auto avec NavigationViewForAuto + flux Turn-by-Turn
- recherche de destination conservée avec Geocoder Android et secours Nominatim

## Important
Le SDK Navigation remplace le SDK Maps classique : `play-services-maps` n'est volontairement pas utilisé.

Une clé API Google Maps Platform autorisée pour le Navigation SDK est nécessaire. Le workflow GitHub attend le secret `GOOGLE_MAPS_API_KEY` et le transmet au build sous le nom `MAPS_API_KEY`.

Google exige l'acceptation des conditions Navigation au premier lancement et impose les exigences de configuration/target SDK du Navigation SDK.

Le support Android Auto Navigation est actuellement documenté par Google comme une fonctionnalité en Preview et nécessite une procédure d'approbation avant distribution publique.

Le signalement d'incidents dépend de la disponibilité régionale et n'est pas disponible dans Android Auto.

## Test
Le build de debug est destiné au premier test. Ne pas utiliser la simulation de trajet en production.
