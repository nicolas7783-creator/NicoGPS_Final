package com.nicogps.app;

import androidx.annotation.NonNull;
import androidx.car.app.CarAppService;
import androidx.car.app.Session;
import androidx.car.app.SessionInfo;
import androidx.car.app.validation.HostValidator;

public class NicoGpsCarAppService extends CarAppService {
    @Override
    @NonNull
    public HostValidator createHostValidator() {
        // Build de test : autorise Android Auto à se connecter.
        // À remplacer par une liste d'hôtes autorisés pour une version publique.
        return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR;
    }

    @Override
    @NonNull
    public Session onCreateSession(@NonNull SessionInfo sessionInfo) {
        return new NicoGpsCarSession();
    }
}
