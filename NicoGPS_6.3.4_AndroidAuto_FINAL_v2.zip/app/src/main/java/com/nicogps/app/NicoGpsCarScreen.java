package com.nicogps.app;

import androidx.annotation.NonNull;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.model.Pane;
import androidx.car.app.model.PaneTemplate;
import androidx.car.app.model.Row;
import androidx.car.app.model.Template;

public class NicoGpsCarScreen extends Screen {
    public NicoGpsCarScreen(@NonNull CarContext carContext) {
        super(carContext);
    }

    @Override
    @NonNull
    public Template onGetTemplate() {
        Row row = new Row.Builder()
                .setTitle("NicoGPS")
                .addText("Android Auto est pret")
                .build();

        Pane pane = new Pane.Builder()
                .addRow(row)
                .build();

        return new PaneTemplate.Builder(pane)
                .setTitle("NicoGPS")
                .build();
    }
}
