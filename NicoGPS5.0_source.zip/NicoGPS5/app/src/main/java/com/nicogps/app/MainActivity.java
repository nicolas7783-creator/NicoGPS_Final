package com.nicogps.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.*;
import com.google.gson.*;
import okhttp3.*;
import org.osmdroid.config.Configuration;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private MapView map;
    private Marker me, dest;
    private Polyline routeLine;
    private FusedLocationProviderClient fused;
    private LocationCallback locationCallback;
    private Location current;
    private boolean follow = true, firstFix = true, routeActive = false, navigation3D = true;
    private PowerManager.WakeLock navigationWakeLock;
    private float displayedBearing = 0f;
    private Polyline routeCasing;

    private TextView status, eta, distance, turnDistance, turnText, turnIcon, speedText, limitText;
    private EditText destination;
    private LinearLayout turnCard, tripCard;
    private TextToSpeech tts;
    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS).build();

    private final ArrayList<GeoPoint> routePoints = new ArrayList<>();
    private final ArrayList<Maneuver> maneuvers = new ArrayList<>();
    private int nextManeuver = 0;
    private long lastReroute = 0, lastLimitLookup = 0;
    private boolean speaking = false, overspeedAnnounced = false;
    private int speedLimit = 0;

    private final ActivityResultLauncher<String[]> perms = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), r -> startGps());

    private static class Maneuver {
        GeoPoint point; String text; String modifier; double distanceFromStart;
        Maneuver(GeoPoint p, String t, String m, double d) { point=p; text=t; modifier=m; distanceFromStart=d; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setKeepScreenOn(true);
        initNavigationWakeLock();
        Configuration.getInstance().load(this, getSharedPreferences("osm",0));
        setContentView(R.layout.activity_main);

        map=findViewById(R.id.map);
        map.setKeepScreenOn(true);
        status=findViewById(R.id.status); destination=findViewById(R.id.destination);
        turnCard=findViewById(R.id.turnCard); tripCard=findViewById(R.id.tripCard);
        eta=findViewById(R.id.eta); distance=findViewById(R.id.distance);
        turnDistance=findViewById(R.id.turnDistance); turnText=findViewById(R.id.turnText); turnIcon=findViewById(R.id.turnIcon);
        speedText=findViewById(R.id.speedText); limitText=findViewById(R.id.limitText);

        map.setMultiTouchControls(true); map.setTilesScaledToDpi(true); map.setBuiltInZoomControls(false);
        map.getController().setZoom(16.0);
        map.setOnTouchListener((v,e)->{ if(e.getAction()==1) follow=false; return false; });

        fused=LocationServices.getFusedLocationProviderClient(this);
        tts=new TextToSpeech(this,s->{ });

        findViewById(R.id.center).setOnClickListener(v->{follow=true; if(current!=null) center(current);});
        findViewById(R.id.search).setOnClickListener(v->searchDestination());
        findViewById(R.id.settings).setOnClickListener(v->settings());
        findViewById(R.id.clearRoute).setOnClickListener(v->clearRoute());
        findViewById(R.id.viewMode).setOnClickListener(v->{
            navigation3D=!navigation3D;
            v.setContentDescription(navigation3D?"Vue conduite pseudo-3D active":"Vue 2D active");
            ((Button)v).setText(navigation3D?"3D ON":"2D");
            if(current!=null && follow){
                updateCamera(current, current.hasBearing()?current.getBearing():displayedBearing, current.hasSpeed()?current.getSpeed()*3.6f:0f, true);
            }
        });

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            perms.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION});
        else startGps();
    }

    private void startGps(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) return;
        LocationRequest req=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000)
                .setMinUpdateIntervalMillis(500).setWaitForAccurateLocation(false).build();
        locationCallback=new LocationCallback(){@Override public void onLocationResult(LocationResult r){
            if(r.getLastLocation()!=null) update(r.getLastLocation());
        }};
        fused.requestLocationUpdates(req,locationCallback,getMainLooper());
        fused.getLastLocation().addOnSuccessListener(l->{if(l!=null)update(l);});
    }

    private void update(Location l){
        if(l==null) return;
        current=l;
        if(me==null){
            me=new Marker(map); me.setTitle("Ma position"); me.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_CENTER);
            Drawable d=ContextCompat.getDrawable(this,R.drawable.ic_navigation_arrow); if(d!=null) me.setIcon(d);
            map.getOverlays().add(me);
        }
        GeoPoint p=new GeoPoint(l.getLatitude(),l.getLongitude()); me.setPosition(p);

        float speed=l.hasSpeed()?l.getSpeed()*3.6f:0f;
        float bearing=l.hasBearing()?l.getBearing():0f;
        if(l.hasBearing() && speed>3) me.setRotation(bearing);

        if(firstFix || follow){
            if(firstFix){
                map.getController().setZoom(17.0);
                map.getController().animateTo(p);
                firstFix=false;
            } else {
                updateCamera(l, bearing, speed, false);
            }
        }

        speedText.setText(String.format(Locale.FRANCE,"%.0f km/h",speed));
        limitText.setText(speedLimit>0?"Limite "+speedLimit:"Limite —");
        status.setText(String.format(Locale.FRANCE,"GPS ±%.0f m",l.hasAccuracy()?l.getAccuracy():0));

        if(routeActive){
            updateNavigation(p,speed);
            if(speed>5 && System.currentTimeMillis()-lastLimitLookup>30000){
                lastLimitLookup=System.currentTimeMillis(); lookupSpeedLimit(l.getLatitude(),l.getLongitude());
            }
        }
        map.invalidate();
    }

    private void adjustZoom(float speed){
        double z=speed<30?17.2:(speed<70?16.2:15.3);
        if(Math.abs(map.getZoomLevelDouble()-z)>0.35) map.getController().setZoom(z);
    }

    private void center(Location l){
        follow=true;
        updateCamera(l, l.hasBearing()?l.getBearing():displayedBearing, l.hasSpeed()?l.getSpeed()*3.6f:0f, true);
    }

    private void updateCamera(Location l, float bearing, float speedKmh, boolean immediate){
        if(l==null)return;
        float effectiveBearing = navigationBearing(l, bearing);
        float target = normalizeBearing(360f - effectiveBearing);
        if(!navigation3D){
            displayedBearing = 0f;
            map.setMapOrientation(0f, true);
            map.getController().animateTo(new GeoPoint(l.getLatitude(),l.getLongitude()));
            adjustZoom(speedKmh);
            return;
        }
        // En mode conduite, on conserve le cap même à très basse vitesse ou à l'arrêt.
        // S'il n'existe pas de cap GPS fiable, on utilise le sens de la route.
        displayedBearing = smoothAngle(displayedBearing, target, immediate ? 1f : 0.28f);
        map.setMapOrientation(displayedBearing, true);
        double z=speedKmh<20?17.2:(speedKmh<60?16.5:15.5);
        if(Math.abs(map.getZoomLevelDouble()-z)>0.25) map.getController().setZoom(z);
        GeoPoint ahead = pointAhead(l.getLatitude(), l.getLongitude(), effectiveBearing, speedKmh<8?55:95);
        map.getController().animateTo(ahead);
    }

    private float navigationBearing(Location l, float fallback){
        if(l!=null && l.hasBearing() && (l.hasSpeed()?l.getSpeed()*3.6f:0f)>0.5f) return normalizeBearing(l.getBearing());
        if(routeActive && !routePoints.isEmpty()){
            int idx=nearestIndex(routePoints,new GeoPoint(l.getLatitude(),l.getLongitude()));
            int next=Math.min(idx+1,routePoints.size()-1);
            if(next!=idx){
                float b=new GeoPoint(l.getLatitude(),l.getLongitude()).bearingTo(routePoints.get(next));
                return normalizeBearing(b);
            }
        }
        return normalizeBearing(fallback);
    }

    private float normalizeBearing(float b){
        b%=360f; if(b<0)b+=360f; return b;
    }

    private float smoothAngle(float current,float target,float factor){
        float diff=((target-current+540f)%360f)-180f;
        return normalizeBearing(current+diff*factor);
    }

    private GeoPoint pointAhead(double lat,double lon,float bearing,double meters){
        double br=Math.toRadians(bearing);
        double dLat=(meters*Math.cos(br))/111320.0;
        double dLon=(meters*Math.sin(br))/(111320.0*Math.max(0.2,Math.cos(Math.toRadians(lat))));
        return new GeoPoint(lat+dLat,lon+dLon);
    }

    private void searchDestination(){
        String q=destination.getText().toString().trim(); if(q.isEmpty()||current==null)return;
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(destination.getWindowToken(),0);
        status.setText("Recherche de la destination…");
        new Thread(()->{
            try{
                Geocoder g=new Geocoder(this,Locale.FRANCE); List<Address> a=g.getFromLocationName(q,1);
                if(a!=null&&!a.isEmpty()){ Address x=a.get(0); runOnUiThread(()->setDestination(x.getLatitude(),x.getLongitude(),x.getAddressLine(0))); }
                else nominatimSearch(q);
            }catch(Exception e){ nominatimSearch(q); }
        }).start();
    }

    private void nominatimSearch(String q){
        try{
            String u="https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=fr&q="+URLEncoder.encode(q,"UTF-8");
            Request req=new Request.Builder().url(u).header("User-Agent","NicoGPS/4.4 contact=nicolasgps").build();
            try(Response res=http.newCall(req).execute()){
                if(!res.isSuccessful()||res.body()==null) throw new IOException("HTTP "+res.code());
                JsonArray a=JsonParser.parseString(res.body().string()).getAsJsonArray();
                if(a.size()==0) throw new IOException("introuvable");
                JsonObject o=a.get(0).getAsJsonObject(); double lat=o.get("lat").getAsDouble(), lon=o.get("lon").getAsDouble();
                String name=o.has("display_name")?o.get("display_name").getAsString():q;
                runOnUiThread(()->setDestination(lat,lon,name));
            }
        }catch(Exception e){runOnUiThread(()->{status.setText("Destination introuvable"); Toast.makeText(this,"Destination introuvable",Toast.LENGTH_SHORT).show();});}
    }

    private void setDestination(double lat,double lon,String title){
        if(dest==null){dest=new Marker(map); dest.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM); map.getOverlays().add(dest);}
        dest.setPosition(new GeoPoint(lat,lon)); dest.setTitle(title);
        turnCard.setVisibility(View.VISIBLE); tripCard.setVisibility(View.VISIBLE);
        turnDistance.setText("Calcul de l’itinéraire…"); turnText.setText(title==null?"Destination":title); turnIcon.setText("➜");
        requestRoute(lat,lon);
    }

    private void requestRoute(double lat,double lon){
        if(current==null)return;
        new Thread(()->{
            try{
                String coords=current.getLongitude()+","+current.getLatitude()+";"+lon+","+lat;
                String url="https://router.project-osrm.org/route/v1/driving/"+coords+
                        "?overview=full&geometries=geojson&steps=true&alternatives=false&annotations=true";
                Request req=new Request.Builder().url(url).header("User-Agent","NicoGPS/4.4").get().build();
                try(Response res=http.newCall(req).execute()){
                    if(!res.isSuccessful()||res.body()==null) throw new IOException("HTTP "+res.code());
                    JsonObject root=JsonParser.parseString(res.body().string()).getAsJsonObject();
                    if(!"Ok".equals(root.get("code").getAsString())) throw new IOException(root.get("code").getAsString());
                    JsonObject route=root.getAsJsonArray("routes").get(0).getAsJsonObject();
                    JsonArray geom=route.getAsJsonObject("geometry").getAsJsonArray("coordinates");
                    ArrayList<GeoPoint> pts=new ArrayList<>();
                    for(JsonElement e:geom){JsonArray pt=e.getAsJsonArray();pts.add(new GeoPoint(pt.get(1).getAsDouble(),pt.get(0).getAsDouble()));}
                    double km=route.get("distance").getAsDouble()/1000.0; long min=Math.max(1,Math.round(route.get("duration").getAsDouble()/60.0));
                    ArrayList<Maneuver> ms=parseManeuvers(route,pts);
                    runOnUiThread(()->drawRoute(pts,km,min,ms));
                }
            }catch(Exception e){runOnUiThread(()->{status.setText("Itinéraire indisponible");Toast.makeText(this,"Itinéraire indisponible",Toast.LENGTH_LONG).show();});}
        }).start();
    }

    private ArrayList<Maneuver> parseManeuvers(JsonObject route, ArrayList<GeoPoint> pts){
        ArrayList<Maneuver> out=new ArrayList<>();
        JsonArray legs=route.getAsJsonArray("legs");
        if(legs==null) return out;
        for(JsonElement le:legs){
            JsonArray steps=le.getAsJsonObject().getAsJsonArray("steps"); if(steps==null) continue;
            for(JsonElement se:steps){
                JsonObject s=se.getAsJsonObject(); JsonObject m=s.getAsJsonObject("maneuver");
                if(m==null||!m.has("location")) continue;
                JsonArray loc=m.getAsJsonArray("location"); GeoPoint p=new GeoPoint(loc.get(1).getAsDouble(),loc.get(0).getAsDouble());
                String type=m.has("type")?m.get("type").getAsString():"";
                String mod=m.has("modifier")?m.get("modifier").getAsString():"";
                String name=s.has("name")?s.get("name").getAsString():"";
                String text=instruction(type,mod,name);
                double startDist=0; // recomputed approximately from route geometry index
                int idx=nearestIndex(pts,p); for(int i=0;i<idx && i<pts.size()-1;i++) startDist+=pts.get(i).distanceToAsDouble(pts.get(i+1));
                if(!"depart".equals(type)) out.add(new Maneuver(p,text,mod,startDist));
            }
        }
        return out;
    }

    private String instruction(String type,String mod,String name){
        if("arrive".equals(type)) return "Vous arrivez à destination";
        String road=name==null||name.isEmpty()?"":(" sur "+name);
        if("roundabout".equals(type)||"rotary".equals(type)) return "Prenez le rond-point"+road;
        if("exit roundabout".equals(type)) return "Sortez du rond-point"+road;
        if("uturn".equals(type)) return "Faites demi-tour"+road;
        if("merge".equals(type)) return "Rejoignez la voie"+road;
        if("fork".equals(type)) return ("left".equals(mod)?"Prenez la branche gauche":"Prenez la branche droite")+road;
        if("straight".equals(mod)||mod.isEmpty()) return "Continuez tout droit"+road;
        if(mod.contains("left")) return "Tournez à gauche"+road;
        if(mod.contains("right")) return "Tournez à droite"+road;
        return "Continuez"+road;
    }

    private void drawRoute(ArrayList<GeoPoint> pts,double km,long min,ArrayList<Maneuver> ms){
        if(routeLine!=null)map.getOverlays().remove(routeLine);
        if(routeCasing!=null)map.getOverlays().remove(routeCasing);
        routePoints.clear(); routePoints.addAll(pts); maneuvers.clear(); maneuvers.addAll(ms); nextManeuver=0;
        routeCasing=new Polyline(); routeCasing.setPoints(pts); routeCasing.setWidth(20f); routeCasing.setColor(0xCC202124); map.getOverlays().add(routeCasing);
        routeLine=new Polyline(); routeLine.setPoints(pts); routeLine.setWidth(12f); routeLine.setColor(0xFF4285F4); map.getOverlays().add(routeLine);
        distance.setText(String.format(Locale.FRANCE,"%.1f km",km)); eta.setText(min+" min");
        routeActive=true; navigation3D=true; speedLimit=0; limitText.setText("Limite —");
        acquireNavigationWakeLock();
        turnDistance.setText("Navigation prête"); turnText.setText(maneuvers.isEmpty()?"Suivez la ligne de route":maneuvers.get(0).text); turnIcon.setText(iconFor(maneuvers.isEmpty()?"":maneuvers.get(0).modifier));
        status.setText("Navigation active"); map.invalidate(); speak("Itinéraire calculé. Navigation démarrée.");
    }

    private void updateNavigation(GeoPoint p,float speed){
        if(routePoints.isEmpty()) return;
        int nearest=nearestIndex(routePoints,p);
        double remaining=0;
        for(int i=nearest;i<routePoints.size()-1;i++) remaining+=routePoints.get(i).distanceToAsDouble(routePoints.get(i+1));

        while(nextManeuver<maneuvers.size()){
            int idx=nearestIndex(routePoints,maneuvers.get(nextManeuver).point);
            if(idx<=nearest+2){
                if(distanceTo(maneuvers.get(nextManeuver).point,p)<35){ nextManeuver++; continue; }
            }
            break;
        }

        if(nextManeuver<maneuvers.size()){
            Maneuver m=maneuvers.get(nextManeuver); double d=distanceTo(p,m.point);
            turnDistance.setText(formatDistance(d)); turnText.setText(m.text); turnIcon.setText(iconFor(m.modifier));
            if(d<550) announceTurn(d,m.text);
        } else if(remaining<40){
            turnDistance.setText("Arrivée"); turnText.setText("Vous êtes arrivé à destination"); turnIcon.setText("✓");
        }

        if(speed>5 && distanceFromRoute(p,routePoints)>45 && System.currentTimeMillis()-lastReroute>15000){
            lastReroute=System.currentTimeMillis(); status.setText("Hors itinéraire • recalcul…");
            if(dest!=null) requestRoute(dest.getPosition().getLatitude(),dest.getPosition().getLongitude());
        }

        if(speedLimit>0 && speed>speedLimit+5){
            status.setText("⚠ Dépassement de la limite");
            if(!overspeedAnnounced){ speak("Attention, vous dépassez la limitation de vitesse."); overspeedAnnounced=true; }
        } else if(speedLimit==0 || speed<=speedLimit){ overspeedAnnounced=false; }
    }

    private void announceTurn(double d,String text){
        if(speaking) return;
        if(d<=500 || d<=200 || d<=80){
            String key="announce_"+nextManeuver+"_"+(d<=80?80:d<=200?200:500);
            if(getPreferences(MODE_PRIVATE).getBoolean(key,false)) return;
            getPreferences(MODE_PRIVATE).edit().putBoolean(key,true).apply();
            speak("Dans "+formatDistance(d)+", "+text);
        }
    }

    private void speak(String s){
        if(tts==null) return; speaking=true;
        tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nicogps");
        map.postDelayed(()->speaking=false,Math.min(7000,Math.max(2000,s.length()*55L)));
    }

    private void lookupSpeedLimit(double lat,double lon){
        new Thread(()->{
            try{
                String q="[out:json][timeout:5];way(around:35,"+lat+","+lon+")[highway][maxspeed];out tags center;";
                String u="https://overpass-api.de/api/interpreter?data="+URLEncoder.encode(q,"UTF-8");
                Request req=new Request.Builder().url(u).header("User-Agent","NicoGPS/4.4").get().build();
                try(Response res=http.newCall(req).execute()){
                    if(!res.isSuccessful()||res.body()==null)return;
                    JsonArray el=JsonParser.parseString(res.body().string()).getAsJsonObject().getAsJsonArray("elements");
                    int limit=0;
                    for(JsonElement e:el){
                        JsonObject tags=e.getAsJsonObject().getAsJsonObject("tags"); if(tags==null||!tags.has("maxspeed"))continue;
                        String raw=tags.get("maxspeed").getAsString().replace(',','.');
                        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d{2,3})").matcher(raw);
                        if(m.find()){limit=Integer.parseInt(m.group(1));break;}
                    }
                    if(limit>0){ final int x=limit; runOnUiThread(()->{speedLimit=x;limitText.setText("Limite "+x);}); }
                }
            }catch(Exception ignored){}
        }).start();
    }

    private int nearestIndex(ArrayList<GeoPoint> pts,GeoPoint p){
        int best=0; double d=Double.MAX_VALUE;
        for(int i=0;i<pts.size();i++){double x=pts.get(i).distanceToAsDouble(p);if(x<d){d=x;best=i;}}
        return best;
    }

    private double distanceFromRoute(GeoPoint p,ArrayList<GeoPoint> pts){
        int idx=nearestIndex(pts,p); double best=pts.get(idx).distanceToAsDouble(p);
        if(idx>0) best=Math.min(best,pointSegmentDistance(p,pts.get(idx-1),pts.get(idx)));
        if(idx<pts.size()-1) best=Math.min(best,pointSegmentDistance(p,pts.get(idx),pts.get(idx+1)));
        return best;
    }

    private double pointSegmentDistance(GeoPoint p,GeoPoint a,GeoPoint b){
        double latScale=111320.0, lonScale=111320.0*Math.cos(Math.toRadians(p.getLatitude()));
        double px=p.getLongitude()*lonScale, py=p.getLatitude()*latScale;
        double ax=a.getLongitude()*lonScale, ay=a.getLatitude()*latScale, bx=b.getLongitude()*lonScale, by=b.getLatitude()*latScale;
        double dx=bx-ax,dy=by-ay,t=((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy); t=Math.max(0,Math.min(1,t));
        double x=ax+t*dx,y=ay+t*dy; return Math.hypot(px-x,py-y);
    }

    private double distanceTo(GeoPoint a,GeoPoint b){return a.distanceToAsDouble(b);}
    private String formatDistance(double d){return d<1000?Math.round(d)+" m":String.format(Locale.FRANCE,"%.1f km",d/1000.0);}
    private String iconFor(String mod){
        if(mod==null)return "➜"; if(mod.contains("left"))return "↰"; if(mod.contains("right"))return "↱"; if("uturn".equals(mod))return "↶"; return "↑";
    }

    private void clearRoute(){
        releaseNavigationWakeLock();
        routeActive=false; routePoints.clear(); maneuvers.clear(); nextManeuver=0; speedLimit=0;
        if(routeLine!=null){map.getOverlays().remove(routeLine);routeLine=null;}
        if(routeCasing!=null){map.getOverlays().remove(routeCasing);routeCasing=null;}
        map.setMapOrientation(0f, true);
        if(dest!=null){map.getOverlays().remove(dest);dest=null;}
        turnCard.setVisibility(View.GONE); tripCard.setVisibility(View.GONE); status.setText("GPS prêt"); map.invalidate();
    }

    private void initNavigationWakeLock(){
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        if(pm!=null){
            navigationWakeLock=pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK |
                    PowerManager.ACQUIRE_CAUSES_WAKEUP |
                    PowerManager.ON_AFTER_RELEASE,
                    "NicoGPS::NavigationScreen");
            navigationWakeLock.setReferenceCounted(false);
        }
    }

    private void acquireNavigationWakeLock(){
        if(navigationWakeLock!=null && !navigationWakeLock.isHeld()){
            try{ navigationWakeLock.acquire(); }catch(Exception ignored){}
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setKeepScreenOn(true);
        if(map!=null) map.setKeepScreenOn(true);
    }

    private void releaseNavigationWakeLock(){
        if(navigationWakeLock!=null && navigationWakeLock.isHeld()){
            try{ navigationWakeLock.release(); }catch(Exception ignored){}
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setKeepScreenOn(false);
        if(map!=null) map.setKeepScreenOn(false);
    }

    private void settings(){new AlertDialog.Builder(this).setTitle("NicoGPS 5.0")
            .setMessage("Navigation GPS avancée\n\n- Position et suivi automatique\n- Flèche orientée selon le déplacement\n- Vue conduite pseudo-3D orientée dans le sens de la route\n- Centrage avancé avec route visible devant\n- Itinéraire OSRM + instructions virage par virage\n- Recalcul automatique si sortie d’itinéraire\n- Guidage vocal\n- Vitesse et tentative de limitation OSM\n- Alerte de dépassement\n- Recherche d’adresse avec secours OpenStreetMap\n\nLes limitations et données routières peuvent être absentes selon les données OpenStreetMap disponibles.")
            .setPositiveButton("OK",null).show();}


    @Override protected void onResume() {
        super.onResume();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setKeepScreenOn(true);
        if (map != null) map.setKeepScreenOn(true);
        if(routeActive) acquireNavigationWakeLock();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            getWindow().getDecorView().setKeepScreenOn(true);
            if (map != null) map.setKeepScreenOn(true);
            if(routeActive) acquireNavigationWakeLock();
        }
    }

    @Override protected void onDestroy(){
        releaseNavigationWakeLock();
        if(fused!=null&&locationCallback!=null)fused.removeLocationUpdates(locationCallback);
        if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy();
    }
}
