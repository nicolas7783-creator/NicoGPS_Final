package com.nicogps.app;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.content.Intent;
import android.view.Surface;
import androidx.annotation.NonNull;
import androidx.car.app.CarAppService;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.Session;
import androidx.car.app.validation.HostValidator;
import androidx.car.app.AppManager;
import androidx.car.app.SurfaceCallback;
import androidx.car.app.SurfaceContainer;
import androidx.car.app.navigation.NavigationManager;
import androidx.car.app.navigation.NavigationManagerCallback;
import androidx.car.app.navigation.model.NavigationTemplate;
import androidx.car.app.model.Action;
import androidx.car.app.model.ActionStrip;
import androidx.car.app.model.CarColor;
import androidx.car.app.model.Distance;
import androidx.car.app.model.Duration;
import androidx.car.app.model.TravelEstimate;
import androidx.car.app.model.TravelEstimate.Builder;
import java.util.concurrent.TimeUnit;

public class NicoGPSCarService extends CarAppService {
    @NonNull @Override public HostValidator createHostValidator() { return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR; }
    @NonNull @Override public Session onCreateSession() { return new Session() {
        @NonNull @Override public Screen onCreateScreen(@NonNull Intent intent) { return new CarScreen(getCarContext()); }
    }; }

    private static class CarScreen extends Screen {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        CarScreen(CarContext c) { super(c); getCarContext().getCarService(AppManager.class).setSurfaceCallback(new SurfaceCallback(){
            @Override public void onSurfaceAvailable(@NonNull SurfaceContainer sc){ draw(sc); }
            @Override public void onSurfaceDestroyed(@NonNull SurfaceContainer sc){}
            @Override public void onStableAreaChanged(@NonNull Rect r){}
            private void draw(SurfaceContainer sc){ Surface s=sc.getSurface(); if(s==null)return; Canvas c=s.lockCanvas(null); if(c==null)return; try{
                c.drawColor(0xFF101820); paint.setColor(0xFF2B78E4); paint.setStrokeWidth(18); paint.setStyle(Paint.Style.STROKE);
                c.drawLine(c.getWidth()/2f,c.getHeight(),c.getWidth()/2f,c.getHeight()*0.58f,paint); c.drawLine(c.getWidth()/2f,c.getHeight()*0.58f,c.getWidth()*0.62f,c.getHeight()*0.30f,paint);
                paint.setColor(0xFFFFFFFF); paint.setStyle(Paint.Style.FILL); float x=c.getWidth()/2f,y=c.getHeight()*0.72f; c.save(); c.rotate(0,x,y); c.drawCircle(x,y,18,paint); c.restore();
            } finally { s.unlockCanvasAndPost(c); }}
        }); }
        @NonNull @Override public androidx.car.app.model.Template onGetTemplate(){
            ActionStrip strip=new ActionStrip.Builder().addAction(new Action.Builder(Action.PAN).setTitle("Carte").build()).build();
            TravelEstimate est=new TravelEstimate.Builder(Distance.create(2400, Distance.UNIT_METERS), Duration.ofMillis(TimeUnit.MINUTES.toMillis(4))).build();
            return new NavigationTemplate.Builder().setBackgroundColor(CarColor.SECONDARY).setActionStrip(strip).setDestinationTravelEstimate(est).build();
        }
    };
}
