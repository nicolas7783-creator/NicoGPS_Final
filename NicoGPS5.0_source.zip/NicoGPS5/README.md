# NicoGPS 5.0

Version de travail : navigation téléphone + première intégration Android Auto.

- GPS haute précision
- Itinéraires OSRM
- guidage vocal
- suivi et recalcul
- vitesse / limitation OSM
- vue conduite pseudo-3D
- écran maintenu actif pendant la navigation
- intégration Android Auto via Android for Cars / NavigationTemplate

L'interface Android Auto utilise les API officielles Android for Cars. La carte personnalisée est rendue via SurfaceCallback.
