# NicoGPS 6.3.2 – Google Maps + Android Auto

Base de compilation stable pour NicoGPS.

- Google Maps SDK Android
- Clé injectée par le workflow GitHub via `GOOGLE_MAPS_API_KEY`
- Android Auto via AndroidX Car App 1.7.0
- Catégorie NAVIGATION
- Écran Android Auto de base avec PaneTemplate
- Rotation automatique du téléphone via `screenOrientation="sensor"`

Cette version constitue la base de compilation avant l'ajout de l'affichage cartographique complet dans Android Auto.
