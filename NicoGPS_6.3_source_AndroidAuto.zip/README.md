# NicoGPS 6.3

Base reconstruite à partir de l'APK NicoGPS 6.2.1 fourni.

Objectifs :
- Google Maps
- Android Auto / Android for Cars
- rotation automatique portrait/paysage
- package conservé : com.nicogps.app

La clé Google Maps n'est pas stockée dans ce projet.
Le workflow GitHub doit injecter le secret GOOGLE_MAPS_API_KEY dans MAPS_API_KEY.

Android Auto utilise AndroidX Car App 1.7.0.
