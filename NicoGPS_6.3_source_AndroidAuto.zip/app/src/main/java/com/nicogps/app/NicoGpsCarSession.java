package com.nicogps.app;

import androidx.annotation.NonNull;
import androidx.car.app.Screen;
import androidx.car.app.Session;

public class NicoGpsCarSession extends Session {
    @Override
    @NonNull
    public Screen onCreateScreen(@NonNull androidx.car.app.CarContext carContext) {
        return new NicoGpsCarScreen(carContext);
    }
}
