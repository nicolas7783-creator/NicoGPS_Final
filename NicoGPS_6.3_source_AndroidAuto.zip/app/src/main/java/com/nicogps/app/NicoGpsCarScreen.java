package com.nicogps.app;

import androidx.annotation.NonNull;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.model.Action;
import androidx.car.app.model.ItemList;
import androidx.car.app.model.Pane;
import androidx.car.app.model.PaneTemplate;
import androidx.car.app.model.Row;
import androidx.car.app.model.Template;
import androidx.car.app.navigation.NavigationTemplate;

public class NicoGpsCarScreen extends Screen {
    public NicoGpsCarScreen(@NonNull CarContext carContext) {
        super(carContext);
    }

    @Override
    @NonNull
    public Template onGetTemplate() {
        Row row = new Row.Builder()
                .setTitle("NicoGPS")
                .addText("Navigation disponible")
                .build();

        Pane pane = new Pane.Builder()
                .addRow(row)
                .build();

        return new NavigationTemplate.Builder()
                .setPane(pane)
                .setActionStrip(
                        new androidx.car.app.model.ActionStrip.Builder()
                                .addAction(
                                        new Action.Builder()
                                                .setTitle("NicoGPS")
                                                .setOnClickListener(() -> invalidate())
                                                .build())
                                .build())
                .build();
    }
}
