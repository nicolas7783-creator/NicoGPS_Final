# NicoGPS 6.3.1

Correction de compilation Android Auto.
- Google Maps conserve la cle injectee par le workflow.
- Android Auto / AndroidX Car App 1.7.0.
- Rotation automatique du telephone via screenOrientation=sensor.
- Session Android Auto utilise onCreateScreen(Intent).
- Ecran Android Auto de base compilable avec PaneTemplate.

Cette version sert de base de compilation stable avant d'ajouter le rendu cartographique Android Auto.
