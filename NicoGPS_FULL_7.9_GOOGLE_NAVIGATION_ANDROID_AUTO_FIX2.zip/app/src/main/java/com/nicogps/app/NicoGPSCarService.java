package com.nicogps.app;

import android.app.Presentation;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.Display;

import androidx.annotation.NonNull;
import androidx.car.app.AppManager;
import androidx.car.app.CarAppService;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.Session;
import androidx.car.app.SurfaceCallback;
import androidx.car.app.SurfaceContainer;
import androidx.car.app.model.Action;
import androidx.car.app.model.ActionStrip;
import androidx.car.app.navigation.model.NavigationTemplate;
import androidx.car.app.validation.HostValidator;

import com.google.android.libraries.navigation.NavigationViewForAuto;

public class NicoGPSCarService extends CarAppService {
    private static final String DISPLAY_NAME = "NicoGPS Navigation";
    @NonNull @Override
    public HostValidator createHostValidator() {
        return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR;
    }

    @NonNull @Override
    public Session onCreateSession() {
        return new Session() {
            @NonNull @Override
            public Screen onCreateScreen(@NonNull Intent intent) {
                return new NicoGPSCarScreen(getCarContext());
            }
        };
    }

    private static final class NicoGPSCarScreen extends Screen implements SurfaceCallback {
        private VirtualDisplayHolder holder;

        NicoGPSCarScreen(CarContext context) {
            super(context);
            context.getCarService(AppManager.class).setSurfaceCallback(this);
        }

        @Override public void onSurfaceAvailable(@NonNull SurfaceContainer sc) {
            if (sc.getSurface() == null || sc.getWidth() == 0 || sc.getHeight() == 0 || sc.getDpi() == 0) return;
            holder = new VirtualDisplayHolder(getCarContext(), sc);
            holder.start();
        }

        @Override public void onSurfaceDestroyed(@NonNull SurfaceContainer sc) {
            if (holder != null) { holder.stop(); holder = null; }
        }

        @Override public void onStableAreaChanged(@NonNull Rect stableArea) {}
        @Override public void onClick(float x, float y) {}
        @Override public void onScroll(float dx, float dy) {}
        @Override public void onScale(float fx, float fy, float scale) {}

        @NonNull @Override
        public androidx.car.app.model.Template onGetTemplate() {
            return new NavigationTemplate.Builder()
                    .setActionStrip(new ActionStrip.Builder().addAction(Action.PAN).build())
                    .setMapActionStrip(new ActionStrip.Builder().addAction(Action.PAN).build())
                    .build();
        }
    }

    private static final class VirtualDisplayHolder {
        private final CarContext context;
        private final SurfaceContainer surfaceContainer;
        private VirtualDisplay virtualDisplay;
        private Presentation presentation;
        private NavigationViewForAuto navigationView;

        VirtualDisplayHolder(CarContext context, SurfaceContainer sc) {
            this.context = context; this.surfaceContainer = sc;
        }

        void start() {
            DisplayManager dm = (DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE);
            virtualDisplay = dm.createVirtualDisplay(DISPLAY_NAME, surfaceContainer.getWidth(), surfaceContainer.getHeight(),
                    surfaceContainer.getDpi(), surfaceContainer.getSurface(), DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY);
            Display display = virtualDisplay.getDisplay();
            presentation = new Presentation(context, display);
            navigationView = new NavigationViewForAuto(context);
            navigationView.onCreate(new Bundle());
            navigationView.onStart();
            navigationView.onResume();
            presentation.setContentView(navigationView);
            presentation.show();
        }

        void stop() {
            if (navigationView != null) {
                navigationView.onPause();
                navigationView.onStop();
                navigationView.onDestroy();
                navigationView = null;
            }
            if (presentation != null) { presentation.dismiss(); presentation = null; }
            if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        }
    }
}
