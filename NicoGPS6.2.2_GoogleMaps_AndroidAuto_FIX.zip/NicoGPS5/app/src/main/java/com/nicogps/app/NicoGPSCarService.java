package com.nicogps.app;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.content.Intent;
import android.view.Surface;
import androidx.annotation.NonNull;
import androidx.car.app.CarAppService;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.Session;
import androidx.car.app.validation.HostValidator;
import androidx.car.app.AppManager;
import androidx.car.app.SurfaceCallback;
import androidx.car.app.SurfaceContainer;
import androidx.car.app.navigation.NavigationManager;
import androidx.car.app.navigation.NavigationManagerCallback;
import androidx.car.app.navigation.model.NavigationTemplate;
import androidx.car.app.model.Action;
import androidx.car.app.model.ActionStrip;
import androidx.car.app.model.CarColor;
import androidx.car.app.model.Distance;
import androidx.car.app.model.DateTimeWithZone;
import androidx.car.app.navigation.model.TravelEstimate;
import java.util.TimeZone;

public class NicoGPSCarService extends CarAppService {
    @NonNull @Override public HostValidator createHostValidator() {
        // APK de test/sideload : Android Auto doit pouvoir se connecter sans blocage de signature.
        return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR;
    }

    @NonNull @Override public Session onCreateSession() {
        return new Session() {
            @NonNull @Override public Screen onCreateScreen(@NonNull Intent intent) {
                return new CarScreen(getCarContext());
            }
        };
    }

    private static class CarScreen extends Screen {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final NavigationManager navigationManager;

        CarScreen(CarContext c) {
            super(c);
            navigationManager = getCarContext().getCarService(NavigationManager.class);
            navigationManager.setNavigationManagerCallback(new NavigationManagerCallback() {
                @Override public void onStopNavigation() {
                    CarNavigationState.active = false;
                    invalidate();
                }
            });

            getCarContext().getCarService(AppManager.class).setSurfaceCallback(new SurfaceCallback() {
                @Override public void onSurfaceAvailable(@NonNull SurfaceContainer sc) { draw(sc); }
                @Override public void onSurfaceDestroyed(@NonNull SurfaceContainer sc) {}
                @Override public void onStableAreaChanged(@NonNull Rect r) {}
                private void draw(SurfaceContainer sc) {
                    Surface s=sc.getSurface();
                    if(s==null)return;
                    Canvas c=s.lockCanvas(null);
                    if(c==null)return;
                    try{
                        c.drawColor(0xFF101820);

                        // Route principale : une ligne centrale simple et lisible sur l'écran voiture.
                        paint.setColor(0xFF2B78E4);
                        paint.setStrokeWidth(18);
                        paint.setStyle(Paint.Style.STROKE);
                        c.drawLine(c.getWidth()/2f,c.getHeight(),c.getWidth()/2f,c.getHeight()*0.58f,paint);
                        c.drawLine(c.getWidth()/2f,c.getHeight()*0.58f,c.getWidth()*0.62f,c.getHeight()*0.30f,paint);

                        // Position du véhicule.
                        paint.setColor(0xFFFFFFFF);
                        paint.setStyle(Paint.Style.FILL);
                        float x=c.getWidth()/2f,y=c.getHeight()*0.72f;
                        c.drawCircle(x,y,18,paint);
                    } finally {
                        s.unlockCanvasAndPost(c);
                    }
                }
            });
        }

        @NonNull @Override public androidx.car.app.model.Template onGetTemplate(){
            ActionStrip strip=new ActionStrip.Builder()
                    .addAction(new Action.Builder(Action.PAN).setTitle("Carte").build())
                    .build();

            int eta=Math.max(1,CarNavigationState.etaMinutes);
            double km=CarNavigationState.remainingKm>0 ? CarNavigationState.remainingKm : 2.4;
            String destination=CarNavigationState.destination==null || CarNavigationState.destination.isEmpty()
                    ? "Destination"
                    : CarNavigationState.destination;

            TravelEstimate est=new TravelEstimate.Builder(
                    Distance.create(km*1000.0, Distance.UNIT_METERS),
                    DateTimeWithZone.create(System.currentTimeMillis()+eta*60_000L, TimeZone.getDefault()))
                    .setRemainingTimeSeconds(eta*60L)
                    .build();

            NavigationTemplate.Builder builder=new NavigationTemplate.Builder()
                    .setBackgroundColor(CarColor.SECONDARY)
                    .setActionStrip(strip)
                    .setDestinationTravelEstimate(est);

            return builder.build();
        }

    }
}
