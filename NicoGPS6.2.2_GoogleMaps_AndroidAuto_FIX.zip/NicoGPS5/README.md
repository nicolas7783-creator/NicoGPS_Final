# NicoGPS 6.2.2 — Google Maps + Android Auto

Base conservée : Google Maps, GPS, guidage, maintien de l'écran allumé.

Corrections incluses :
- recherche d'adresse : résultats dédoublonnés plus strictement et libellés courts (ex. `77160 Provins, France`) ;
- panneau inférieur : valeurs ETA/distance réinitialisées proprement avant un nouveau calcul ;
- Android Auto : service de navigation déclaré comme navigation + cluster, `HostValidator` de test, affichage de carte de conduite via surface ;
- Android Auto : suppression du lanceur `CarAppActivity` en double ;
- rotation automatique du téléphone conservée (`sensor`) ;
- version 6.2.2.

La clé Google Maps reste injectée au build via `MAPS_API_KEY` / `GOOGLE_MAPS_API_KEY` selon le workflow.
