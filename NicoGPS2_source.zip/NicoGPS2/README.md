# NicoGPS 3.1

Application Android de navigation de test.

Fonctions incluses :
- position GPS réelle et suivi de position
- carte OpenStreetMap via osmdroid
- recherche de destination
- calcul d'itinéraire routier via OSRM, sans clé OpenRouteService
- tracé de l'itinéraire sur la carte
- distance et durée estimées
- synthèse vocale à la création de l'itinéraire
- bouton de recentrage

## Compilation GitHub Actions
Le projet contient son propre workflow dans `.github/workflows/build.yml`.
Il peut être lancé manuellement depuis Actions et se lance aussi après un push sur `main`.

Le workflow utilise Java 17 et Gradle 8.11.1.
