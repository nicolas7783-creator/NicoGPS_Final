package com.nicogps.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.google.android.gms.location.*;
import com.google.gson.*;
import okhttp3.*;
import org.osmdroid.config.Configuration;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;
import java.io.IOException;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private MapView map; private Marker me, dest; private Polyline routeLine;
    private FusedLocationProviderClient fused; private LocationCallback locationCallback;
    private Location current; private boolean follow=true; private boolean firstFix=true;
    private TextView status, eta, distance, turnDistance, turnText, turnIcon;
    private EditText destination; private LinearLayout turnCard, tripCard; private TextToSpeech tts;
    private final OkHttpClient http = new OkHttpClient();
    private final ActivityResultLauncher<String[]> perms = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), r -> startGps());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Configuration.getInstance().load(this, getSharedPreferences("osm",0));
        setContentView(R.layout.activity_main);
        map=findViewById(R.id.map); status=findViewById(R.id.status); destination=findViewById(R.id.destination);
        turnCard=findViewById(R.id.turnCard); tripCard=findViewById(R.id.tripCard);
        eta=findViewById(R.id.eta); distance=findViewById(R.id.distance);
        turnDistance=findViewById(R.id.turnDistance); turnText=findViewById(R.id.turnText); turnIcon=findViewById(R.id.turnIcon);
        map.setMultiTouchControls(true); map.setTilesScaledToDpi(true); map.setBuiltInZoomControls(false);
        map.getController().setZoom(16.0);
        map.setOnTouchListener((v,e)->{ if(e.getAction()==1) follow=false; return false; });
        fused=LocationServices.getFusedLocationProviderClient(this);
        tts=new TextToSpeech(this,s->{ });
        findViewById(R.id.center).setOnClickListener(v->{follow=true; if(current!=null) center(current);});
        findViewById(R.id.search).setOnClickListener(v->searchDestination());
        findViewById(R.id.settings).setOnClickListener(v->settings());
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            perms.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION});
        else startGps();
    }

    private void startGps(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) return;
        LocationRequest req=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000)
                .setMinUpdateIntervalMillis(500).setWaitForAccurateLocation(false).build();
        locationCallback=new LocationCallback(){@Override public void onLocationResult(LocationResult r){
            if(r.getLastLocation()!=null) update(r.getLastLocation());
        }};
        fused.requestLocationUpdates(req,locationCallback,getMainLooper());
        fused.getLastLocation().addOnSuccessListener(l->{if(l!=null)update(l);});
    }

    private void update(Location l){
        current=l;
        if(me==null){ me=new Marker(map); me.setTitle("Ma position"); me.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_CENTER); map.getOverlays().add(me); }
        GeoPoint p=new GeoPoint(l.getLatitude(),l.getLongitude()); me.setPosition(p);
        if(firstFix || follow){ map.getController().animateTo(p); if(firstFix) map.getController().setZoom(16.5); firstFix=false; }
        float speed=l.hasSpeed()?l.getSpeed()*3.6f:0; float acc=l.hasAccuracy()?l.getAccuracy():-1;
        String gps=String.format(Locale.FRANCE,"%.0f km/h  •  GPS ±%.0f m",speed,Math.max(0,acc));
        status.setText(gps); map.invalidate();
    }

    private void center(Location l){ map.getController().animateTo(new GeoPoint(l.getLatitude(),l.getLongitude())); map.getController().setZoom(17.0); }

    private void searchDestination(){
        String q=destination.getText().toString().trim(); if(q.isEmpty()||current==null)return;
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(destination.getWindowToken(),0);
        status.setText("Recherche de la destination…");
        new Thread(()->{try{
            Geocoder g=new Geocoder(this,Locale.FRANCE); List<Address> a=g.getFromLocationName(q,1);
            if(a!=null&&!a.isEmpty()){ Address x=a.get(0); runOnUiThread(()->setDestination(x.getLatitude(),x.getLongitude(),x.getAddressLine(0))); }
            else runOnUiThread(()->Toast.makeText(this,"Destination introuvable",Toast.LENGTH_SHORT).show());
        }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Recherche impossible",Toast.LENGTH_SHORT).show());}}).start();
    }

    private void setDestination(double lat,double lon,String title){
        if(dest==null){dest=new Marker(map); dest.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM); map.getOverlays().add(dest);}
        dest.setPosition(new GeoPoint(lat,lon)); dest.setTitle(title);
        turnCard.setVisibility(android.view.View.VISIBLE); tripCard.setVisibility(android.view.View.VISIBLE);
        turnDistance.setText("Calcul de l'itinéraire…"); turnText.setText(title==null?"Destination":title);
        requestRoute(lat,lon);
    }

    private void requestRoute(double lat,double lon){
        if(current==null)return;
        new Thread(()->{try{
            String coords=current.getLongitude()+","+current.getLatitude()+";"+lon+","+lat;
            String url="https://router.project-osrm.org/route/v1/driving/"+coords+"?overview=full&geometries=geojson&steps=true";
            Request req=new Request.Builder().url(url).header("User-Agent","NicoGPS/3.1").get().build();
            Response res=http.newCall(req).execute(); if(!res.isSuccessful())throw new IOException("HTTP "+res.code());
            String raw=res.body()!=null?res.body().string():""; JsonObject root=JsonParser.parseString(raw).getAsJsonObject();
            if(!"Ok".equals(root.get("code").getAsString()))throw new IOException(root.get("code").getAsString());
            JsonObject route=root.getAsJsonArray("routes").get(0).getAsJsonObject();
            JsonArray geom=route.getAsJsonObject("geometry").getAsJsonArray("coordinates"); ArrayList<GeoPoint> pts=new ArrayList<>();
            for(JsonElement e:geom){JsonArray pt=e.getAsJsonArray();pts.add(new GeoPoint(pt.get(1).getAsDouble(),pt.get(0).getAsDouble()));}
            double km=route.get("distance").getAsDouble()/1000.0; long min=Math.max(1,Math.round(route.get("duration").getAsDouble()/60.0));
            runOnUiThread(()->drawRoute(pts,km,min));
        }catch(Exception e){runOnUiThread(()->{status.setText("Itinéraire indisponible");Toast.makeText(this,"Itinéraire indisponible",Toast.LENGTH_LONG).show();});}}).start();
    }

    private void drawRoute(ArrayList<GeoPoint> pts,double km,long min){
        if(routeLine!=null)map.getOverlays().remove(routeLine);
        routeLine=new Polyline(); routeLine.setPoints(pts); routeLine.setWidth(14f); map.getOverlays().add(routeLine);
        distance.setText(String.format(Locale.FRANCE,"%.1f km",km)); eta.setText(min+" min");
        turnDistance.setText("Itinéraire prêt"); turnText.setText("Suivez la ligne de route"); turnIcon.setText("➜");
        status.setText("Navigation prête  •  "+String.format(Locale.FRANCE,"%.1f km",km));
        map.invalidate(); speak("Itinéraire calculé. Environ "+Math.round(km)+" kilomètres.");
    }

    private void speak(String s){if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nicogps");}

    private void settings(){new AlertDialog.Builder(this).setTitle("NicoGPS 3.1")
        .setMessage("NicoGPS 3.1\n\nInterface de navigation style GPS moderne.\nCarte OpenStreetMap + routage OSRM.\n\nVersion test : itinéraire sans clé OpenRouteService.")
        .setPositiveButton("OK",null).show();}

    @Override protected void onDestroy(){
        if(fused!=null && locationCallback!=null) fused.removeLocationUpdates(locationCallback);
        if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy();
    }
}
