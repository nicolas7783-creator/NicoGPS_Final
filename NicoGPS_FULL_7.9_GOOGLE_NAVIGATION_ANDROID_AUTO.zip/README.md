# NicoGPS 7.9 — Google Navigation + Android Auto

Base: NicoGPS Google Maps 6.2.1 that was previously working.

## Included
- Google Navigation SDK 7.9.0
- Traffic prompts and traffic incident cards
- Alternate routes
- Voice guidance and Bluetooth audio
- Toll/highway/ferry routing preferences available through RoutingOptions
- Custom yellow incident button
- Google incident reporting for supported reports during active phone navigation
- Local categories for custom events such as animal/obstacle and stopped vehicle
- Android Auto NavigationViewForAuto surface

## Build
The project requires compileSdk/targetSdk 36, minSdk 24, Gradle 8.13 and AGP 8.13.2 for Navigation SDK 7.7+.

The workflow injects the GitHub secret GOOGLE_MAPS_API_KEY into AndroidManifest.xml.

IMPORTANT: the Google Cloud project/key used by NicoGPS must have the Navigation SDK for Android enabled. The existing Android application restriction (package com.nicogps.app + certificate SHA-1) should be retained.

Android Auto NavigationViewForAuto is currently documented by Google as pre-GA and requires the Android Auto app approval process before public launch.
