package com.nicogps.app;

public final class CarNavigationState {
    private CarNavigationState() {}
    public static volatile boolean active = false;
    public static volatile String destination = "";
    public static volatile String nextInstruction = "";
    public static volatile String nextDistance = "";
    public static volatile int etaMinutes = 0;
    public static volatile double remainingKm = 0;
    public static volatile float speedKmh = 0;
}
