package com.nicogps.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.google.android.libraries.navigation.AudioGuidanceSettings;
import com.google.android.libraries.navigation.ListenableResultFuture;
import com.google.android.libraries.navigation.NavigationApi;
import com.google.android.libraries.navigation.Navigator;
import com.google.android.libraries.navigation.RoutingOptions;
import com.google.android.libraries.navigation.SupportNavigationFragment;
import com.google.android.libraries.navigation.Waypoint;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;
import okhttp3.OkHttpClient;
import okhttp3.Request;

public class MainActivity extends AppCompatActivity {
    private Navigator navigator;
    private SupportNavigationFragment navFragment;
    private RoutingOptions routingOptions;
    private boolean navigationActive = false;
    private boolean voiceMuted = false;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final OkHttpClient http = new OkHttpClient();
    private ActivityResultLauncher<String[]> permissionLauncher;
    private android.widget.TextView status;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        status = findViewById(R.id.status);
        navFragment = (SupportNavigationFragment)getSupportFragmentManager().findFragmentById(R.id.navigation_fragment);

        navFragment.setTrafficPromptsEnabled(true);
        navFragment.setTrafficIncidentCardsEnabled(true);
        navFragment.setReportIncidentButtonEnabled(false);
        navFragment.setSpeedometerEnabled(true);
        navFragment.setSpeedLimitIconEnabled(true);
        navFragment.setRecenterButtonEnabled(true);
        navFragment.setTripProgressBarEnabled(true);

        permissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r -> {
            if (hasLocationPermission()) initializeNavigator();
            else toast("Autorisation GPS nécessaire pour NicoGPS.");
        });

        findViewById(R.id.search).setOnClickListener(v -> showSearchDialog());
        findViewById(R.id.alert).setOnClickListener(v -> showIncidentMenu());
        findViewById(R.id.sound).setOnClickListener(v -> setVoice(false));
        findViewById(R.id.mute).setOnClickListener(v -> setVoice(true));
        findViewById(R.id.stop).setOnClickListener(v -> stopNavigation());

        if (hasLocationPermission()) initializeNavigator();
        else permissionLauncher.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void initializeNavigator() {
        NavigationApi.getNavigator(this, new NavigationApi.NavigatorListener() {
            @Override public void onNavigatorReady(Navigator n) {
                navigator = n;
                routingOptions = new RoutingOptions()
                        .travelMode(RoutingOptions.TravelMode.DRIVING)
                        .avoidFerries(true)
                        .alternateRoutesStrategy(com.google.android.libraries.navigation.AlternateRoutesStrategy.SHOW_ALL);
                setVoice(false);
                status.setText("NicoGPS prêt — trafic Google activé");
            }
            @Override public void onError(@NavigationApi.ErrorCode int errorCode) {
                toast("Navigation Google : " + errorCode);
                status.setText("Erreur Navigation SDK : " + errorCode);
            }
        });
    }

    private void showSearchDialog() {
        final EditText input = new EditText(this);
        input.setHint("Ville, adresse ou lieu");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        new AlertDialog.Builder(this).setTitle("Destination").setView(input)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Rechercher", (d,w) -> searchNominatim(input.getText().toString().trim()))
                .show();
    }

    private void searchNominatim(String q) {
        if (q.isEmpty()) return;
        status.setText("Recherche : " + q);
        executor.execute(() -> {
            try {
                String url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&countrycodes=fr&q=" + java.net.URLEncoder.encode(q,"UTF-8");
                Request req = new Request.Builder().url(url).header("User-Agent","NicoGPS/7.9 contact=nico").build();
                String body = http.newCall(req).execute().body().string();
                JSONArray arr = new JSONArray(body);
                ArrayList<String> names = new ArrayList<>();
                ArrayList<Double> lats = new ArrayList<>(), lons = new ArrayList<>();
                for(int i=0;i<arr.length();i++){
                    JSONObject o=arr.getJSONObject(i);
                    names.add(o.optString("display_name",q));
                    lats.add(Double.parseDouble(o.getString("lat")));
                    lons.add(Double.parseDouble(o.getString("lon")));
                }
                runOnUiThread(() -> showResults(names,lats,lons));
            } catch(Exception e){ runOnUiThread(() -> toast("Recherche impossible : " + e.getMessage())); }
        });
    }

    private void showResults(ArrayList<String> names, ArrayList<Double> lats, ArrayList<Double> lons) {
        if(names.isEmpty()){ toast("Aucun résultat."); return; }
        String[] items = names.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Choisir la destination").setItems(items, (d,which) -> startRoute(lats.get(which),lons.get(which),names.get(which)))
                .setNegativeButton("Annuler",null).show();
    }

    private void startRoute(double lat,double lon,String title) {
        if(navigator==null){ toast("Navigation Google pas encore prête."); return; }
        try {
            Waypoint wp=Waypoint.builder().setLatLng(lat,lon).setTitle(title).setVehicleStopover(true).build();
            ListenableResultFuture<Navigator.RouteStatus> future=navigator.setDestination(wp,routingOptions);
            future.setOnResultListener(code -> runOnUiThread(() -> {
                if(code==Navigator.RouteStatus.OK){
                    navigationActive=true;
                    CarNavigationState.active=true;
                    CarNavigationState.destination=title;
                    navigator.startGuidance();
                    status.setText("Navigation vers " + title);
                    toast("Itinéraire calculé avec trafic + itinéraires alternatifs");
                } else {
                    toast("Itinéraire : " + code);
                    status.setText("Impossible de calculer l'itinéraire");
                }
            }));
        } catch(Exception e){ toast("Destination invalide : " + e.getMessage()); }
    }

    private void setVoice(boolean mute) {
        voiceMuted=mute;
        if(navigator==null) return;
        AudioGuidanceSettings.GuidanceMode mode = mute ? AudioGuidanceSettings.GuidanceMode.SILENT : AudioGuidanceSettings.GuidanceMode.VOICE_ALERTS_AND_GUIDANCE;
        navigator.setAudioGuidanceSettings(AudioGuidanceSettings.builder().setGuidanceMode(mode).setBluetoothAudioEnabled(true).build());
        status.setText(mute ? "Guidage vocal coupé" : "Guidage vocal activé");
    }

    private void stopNavigation() {
        if(navigator!=null) navigator.stopGuidance();
        navigationActive=false;
        CarNavigationState.active=false;
        status.setText("NicoGPS prêt");
    }

    private void showIncidentMenu() {
        String[] items={"🚓 Police / contrôle", "💥 Accident", "📷 Radar / caméra", "🚧 Bouchon / circulation dense", "👷 Travaux / voie fermée", "🦌 Animal / obstacle", "🚗 Véhicule arrêté", "⚠️ Autre danger"};
        new AlertDialog.Builder(this).setTitle("🟡 Signaler un événement").setItems(items,(d,which)->{
            if(navigationActive && which<=4 && navFragment.showReportIncidentsPanel()){
                status.setText("Panneau de signalement Google ouvert");
            } else {
                saveLocalIncident(items[which]);
            }
        }).setNegativeButton("Annuler",null).show();
    }

    private void saveLocalIncident(String label){
        getPreferences(MODE_PRIVATE).edit().putString("lastIncident",label).putLong("lastIncidentTime",System.currentTimeMillis()).apply();
        toast(label + " enregistré sur le téléphone");
    }

    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }

    @Override protected void onDestroy(){ executor.shutdownNow(); super.onDestroy(); }
}
