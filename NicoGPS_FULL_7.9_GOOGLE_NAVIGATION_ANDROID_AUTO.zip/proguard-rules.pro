# NicoGPS - Navigation SDK keeps its own required rules.
-keep class com.nicogps.app.** { *; }
