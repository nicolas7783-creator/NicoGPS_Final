# NicoGPS 5.1

Version de correction du projet NicoGPS 5.0.

- Navigation GPS OSRM
- Vue conduite pseudo-3D
- Maintien de l'écran pendant la navigation
- Interface navigation automobile
- Base d'intégration Android Auto avec Car App Library 1.7.0
- Corrections de compilation Android Auto (TravelEstimate / durée et conversion du cap)

Projet Android destiné à être compilé via GitHub Actions.
