# NicoGPS 6.0

Version finale de travail de NicoGPS : navigation routière, suivi GPS, guidage vocal, vue conduite pseudo-3D, écran maintenu actif, recherche par loupe, destinations favorites et compatibilité Android Auto via Android for Cars.

La partie Android Auto utilise le modèle de navigation officiel `CarAppService` / `NavigationTemplate`. La carte du téléphone et la session voiture sont séparées par l’architecture Android for Cars.
