package com.nicogps.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.*;
import com.google.gson.*;
import okhttp3.*;
import org.osmdroid.config.Configuration;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private MapView map;
    private Marker me, dest;
    private Polyline routeLine;
    private FusedLocationProviderClient fused;
    private LocationCallback locationCallback;
    private Location current;
    private boolean follow = true, firstFix = true, routeActive = false, navigation3D = true;
    private PowerManager.WakeLock navigationWakeLock;
    private float displayedBearing = 0f;
    private Polyline routeCasing;

    private TextView status, eta, distance, turnDistance, turnText, turnIcon, speedText, limitText, roadName;
    private String lastDestinationTitle = "";
    private LinearLayout turnCard, tripCard;
    private TextToSpeech tts;
    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS).build();

    private final ArrayList<GeoPoint> routePoints = new ArrayList<>();
    private final ArrayList<Maneuver> maneuvers = new ArrayList<>();
    private int nextManeuver = 0;
    private long lastReroute = 0, lastLimitLookup = 0;
    private boolean speaking = false, overspeedAnnounced = false, voiceMuted = false;
    private int speedLimit = 0;

    private final ActivityResultLauncher<String[]> perms = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), r -> startGps());

    private static class Maneuver {
        GeoPoint point; String text; String modifier; double distanceFromStart;
        Maneuver(GeoPoint p, String t, String m, double d) { point=p; text=t; modifier=m; distanceFromStart=d; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setKeepScreenOn(true);
        initNavigationWakeLock();
        Configuration.getInstance().load(this, getSharedPreferences("osm",0));
        setContentView(R.layout.activity_main);

        map=findViewById(R.id.map);
        map.setKeepScreenOn(true);
        status=findViewById(R.id.status);
        turnCard=findViewById(R.id.turnCard); tripCard=findViewById(R.id.tripCard);
        eta=findViewById(R.id.eta); distance=findViewById(R.id.distance);
        turnDistance=findViewById(R.id.turnDistance); turnText=findViewById(R.id.turnText); turnIcon=findViewById(R.id.turnIcon);
        speedText=findViewById(R.id.speedText); limitText=findViewById(R.id.limitText); roadName=findViewById(R.id.roadName);

        map.setMultiTouchControls(true); map.setTilesScaledToDpi(true); map.setBuiltInZoomControls(false);
        map.getController().setZoom(16.0);
        map.setOnTouchListener((v,e)->{ if(e.getAction()==1) follow=false; return false; });

        fused=LocationServices.getFusedLocationProviderClient(this);
        tts=new TextToSpeech(this,s->{ });

        findViewById(R.id.center).setOnClickListener(v->{follow=true; if(current!=null) center(current);});
        findViewById(R.id.search).setOnClickListener(v->showSearchDialog());
        findViewById(R.id.sound).setOnClickListener(v->{voiceMuted=false; Toast.makeText(this,"🔊 Guidage vocal activé",Toast.LENGTH_SHORT).show();});
        findViewById(R.id.mute).setOnClickListener(v->{voiceMuted=true; Toast.makeText(this,"🔇 Guidage vocal coupé",Toast.LENGTH_SHORT).show();});
        findViewById(R.id.alert).setOnClickListener(v->Toast.makeText(this,"⚠ Alerte : fonction à configurer",Toast.LENGTH_SHORT).show());
        findViewById(R.id.settings).setOnClickListener(v->settings());
        findViewById(R.id.clearRoute).setOnClickListener(v->clearRoute());
        findViewById(R.id.favorite).setOnClickListener(v->saveCurrentFavorite());
        findViewById(R.id.viewMode).setOnClickListener(v->{
            navigation3D=!navigation3D;
            v.setContentDescription(navigation3D?"Vue conduite pseudo-3D active":"Vue 2D active");
            ((Button)v).setText(navigation3D?"3D ON":"2D");
            if(current!=null && follow){
                updateCamera(current, current.hasBearing()?current.getBearing():displayedBearing, current.hasSpeed()?current.getSpeed()*3.6f:0f, true);
            }
        });

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            perms.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION});
        else startGps();
    }

    private void startGps(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) return;
        LocationRequest req=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000)
                .setMinUpdateIntervalMillis(500).setWaitForAccurateLocation(false).build();
        locationCallback=new LocationCallback(){@Override public void onLocationResult(LocationResult r){
            if(r.getLastLocation()!=null) update(r.getLastLocation());
        }};
        fused.requestLocationUpdates(req,locationCallback,getMainLooper());
        fused.getLastLocation().addOnSuccessListener(l->{if(l!=null)update(l);});
    }

    private void update(Location l){
        if(l==null) return;
        current=l;
        if(me==null){
            me=new Marker(map); me.setTitle("Ma position"); me.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_CENTER);
            Drawable d=ContextCompat.getDrawable(this,R.drawable.ic_navigation_arrow); if(d!=null) me.setIcon(d);
            map.getOverlays().add(me);
        }
        GeoPoint p=new GeoPoint(l.getLatitude(),l.getLongitude()); me.setPosition(p);

        float speed=l.hasSpeed()?l.getSpeed()*3.6f:0f;
        float bearing=l.hasBearing()?l.getBearing():0f;
        if(l.hasBearing() && speed>3) me.setRotation(bearing);

        if(firstFix || follow){
            if(firstFix){
                map.getController().setZoom(17.0);
                map.getController().animateTo(p);
                firstFix=false;
            } else {
                updateCamera(l, bearing, speed, false);
            }
        }

        speedText.setText(String.format(Locale.FRANCE,"%.0f",speed)); CarNavigationState.speedKmh=speed;
        limitText.setText(speedLimit>0?String.valueOf(speedLimit):"km/h");
        status.setText(String.format(Locale.FRANCE,"GPS ±%.0f m",l.hasAccuracy()?l.getAccuracy():0));

        if(routeActive){
            updateNavigation(p,speed);
            if(speed>5 && System.currentTimeMillis()-lastLimitLookup>30000){
                lastLimitLookup=System.currentTimeMillis(); lookupSpeedLimit(l.getLatitude(),l.getLongitude());
            }
        }
        map.invalidate();
    }

    private void adjustZoom(float speed){
        double z=speed<30?17.2:(speed<70?16.2:15.3);
        if(Math.abs(map.getZoomLevelDouble()-z)>0.35) map.getController().setZoom(z);
    }

    private void center(Location l){
        follow=true;
        updateCamera(l, l.hasBearing()?l.getBearing():displayedBearing, l.hasSpeed()?l.getSpeed()*3.6f:0f, true);
    }

    private void updateCamera(Location l, float bearing, float speedKmh, boolean immediate){
        if(l==null)return;
        float effectiveBearing = navigationBearing(l, bearing);
        float target = normalizeBearing(360f - effectiveBearing);
        if(!navigation3D){
            displayedBearing = 0f;
            map.setMapOrientation(0f, true);
            map.getController().animateTo(new GeoPoint(l.getLatitude(),l.getLongitude()));
            adjustZoom(speedKmh);
            return;
        }
        // En mode conduite, on conserve le cap même à très basse vitesse ou à l'arrêt.
        // S'il n'existe pas de cap GPS fiable, on utilise le sens de la route.
        displayedBearing = smoothAngle(displayedBearing, target, immediate ? 1f : 0.28f);
        map.setMapOrientation(displayedBearing, true);
        double z=speedKmh<20?17.2:(speedKmh<60?16.5:15.5);
        if(Math.abs(map.getZoomLevelDouble()-z)>0.25) map.getController().setZoom(z);
        GeoPoint ahead = pointAhead(l.getLatitude(), l.getLongitude(), effectiveBearing, speedKmh<8?55:95);
        map.getController().animateTo(ahead);
    }

    private float navigationBearing(Location l, float fallback){
        if(l!=null && l.hasBearing() && (l.hasSpeed()?l.getSpeed()*3.6f:0f)>0.5f) return normalizeBearing(l.getBearing());
        if(routeActive && !routePoints.isEmpty()){
            int idx=nearestIndex(routePoints,new GeoPoint(l.getLatitude(),l.getLongitude()));
            int next=Math.min(idx+1,routePoints.size()-1);
            if(next!=idx){
                float b=(float)new GeoPoint(l.getLatitude(),l.getLongitude()).bearingTo(routePoints.get(next));
                return normalizeBearing(b);
            }
        }
        return normalizeBearing(fallback);
    }

    private float normalizeBearing(float b){
        b%=360f; if(b<0)b+=360f; return b;
    }

    private float smoothAngle(float current,float target,float factor){
        float diff=((target-current+540f)%360f)-180f;
        return normalizeBearing(current+diff*factor);
    }

    private GeoPoint pointAhead(double lat,double lon,float bearing,double meters){
        double br=Math.toRadians(bearing);
        double dLat=(meters*Math.cos(br))/111320.0;
        double dLon=(meters*Math.sin(br))/(111320.0*Math.max(0.2,Math.cos(Math.toRadians(lat))));
        return new GeoPoint(lat+dLat,lon+dLon);
    }

    private void showSearchDialog(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,8,24,4);
        EditText input=new EditText(this); input.setSingleLine(true); input.setHint("Adresse, ville ou lieu"); input.setTextColor(0xFF111111); input.setHintTextColor(0xFF777777);
        box.addView(input,new LinearLayout.LayoutParams(-1,60));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
        Button go=new Button(this); go.setText("Rechercher"); Button fav=new Button(this); fav.setText("⭐ Favoris");
        row.addView(go,new LinearLayout.LayoutParams(0,55,1)); row.addView(fav,new LinearLayout.LayoutParams(0,55,1)); box.addView(row);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Rechercher une destination").setView(box).create();
        go.setOnClickListener(v->{ String q=input.getText().toString().trim(); if(!q.isEmpty()){ dialog.dismiss(); searchDestination(q); }});
        input.setOnEditorActionListener((v,a,e)->{ String q=input.getText().toString().trim(); if(!q.isEmpty()){ dialog.dismiss(); searchDestination(q); } return true; });
        fav.setOnClickListener(v->{dialog.dismiss(); showFavorites();});
        dialog.setOnShowListener(v->input.requestFocus()); dialog.getWindow(); dialog.show();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }

    private static class SearchResult {
        final double lat, lon;
        final String title;
        SearchResult(double lat, double lon, String title) { this.lat = lat; this.lon = lon; this.title = title; }
    }

    private void searchDestination(String q){
        if(q.isEmpty()||current==null)return;
        status.setText("Recherche des destinations…");
        new Thread(()->{
            ArrayList<SearchResult> results = new ArrayList<>();
            try{
                Geocoder g=new Geocoder(this,Locale.FRANCE);
                List<Address> addresses=g.getFromLocationName(q,5);
                if(addresses!=null){
                    for(Address x: addresses){
                        if(x.hasLatitude() && x.hasLongitude()){
                            String title=x.getAddressLine(0);
                            if(title==null || title.trim().isEmpty()) title=q;
                            results.add(new SearchResult(x.getLatitude(),x.getLongitude(),title));
                        }
                    }
                }
            }catch(Exception ignored){}

            // Nominatim fournit plusieurs résultats lorsque le Geocoder Android n'en renvoie pas assez.
            if(results.size()<3){
                try { results.addAll(nominatimSearchResults(q)); } catch(Exception ignored) {}
            }

            // Supprime les doublons très proches.
            ArrayList<SearchResult> unique = new ArrayList<>();
            for(SearchResult r : results){
                boolean duplicate=false;
                for(SearchResult u : unique){
                    if(Math.abs(r.lat-u.lat)<0.0001 && Math.abs(r.lon-u.lon)<0.0001){ duplicate=true; break; }
                }
                if(!duplicate) unique.add(r);
                if(unique.size()>=5) break;
            }

            runOnUiThread(()->showSearchResults(q, unique));
        }).start();
    }

    private ArrayList<SearchResult> nominatimSearchResults(String q) throws Exception {
        ArrayList<SearchResult> results = new ArrayList<>();
        String u="https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&countrycodes=fr&q="+URLEncoder.encode(q,"UTF-8");
        Request req=new Request.Builder().url(u).header("User-Agent","NicoGPS/6.1 contact=nicolasgps").build();
        try(Response res=http.newCall(req).execute()){
            if(!res.isSuccessful()||res.body()==null) throw new IOException("HTTP "+res.code());
            JsonArray a=JsonParser.parseString(res.body().string()).getAsJsonArray();
            for(JsonElement e : a){
                JsonObject o=e.getAsJsonObject();
                double lat=o.get("lat").getAsDouble(), lon=o.get("lon").getAsDouble();
                String name=o.has("display_name")?o.get("display_name").getAsString():q;
                results.add(new SearchResult(lat,lon,name));
            }
        }
        return results;
    }

    private void showSearchResults(String q, ArrayList<SearchResult> results){
        if(results.isEmpty()){
            status.setText("Destination introuvable");
            Toast.makeText(this,"Aucun résultat pour « "+q+" »",Toast.LENGTH_SHORT).show();
            return;
        }
        status.setText("Choisissez une destination");
        String[] labels=new String[results.size()];
        for(int i=0;i<results.size();i++) labels[i]=results.get(i).title;
        new AlertDialog.Builder(this)
                .setTitle("Choisir la destination")
                .setItems(labels,(dialog,which)->{
                    SearchResult r=results.get(which);
                    setDestination(r.lat,r.lon,r.title);
                })
                .setNegativeButton("Annuler",(dialog,which)->status.setText("GPS prêt"))
                .show();
    }

    private void setDestination(double lat,double lon,String title){
        if(dest==null){dest=new Marker(map); dest.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM); map.getOverlays().add(dest);}
        dest.setPosition(new GeoPoint(lat,lon)); dest.setTitle(title); lastDestinationTitle=title==null?"Destination":title; CarNavigationState.destination=lastDestinationTitle;
        turnCard.setVisibility(View.VISIBLE); tripCard.setVisibility(View.VISIBLE);
        turnDistance.setText("Calcul de l’itinéraire…"); turnText.setText(title==null?"Destination":title); turnIcon.setText("➜");
        requestRoute(lat,lon);
    }

    private void requestRoute(double lat,double lon){
        if(current==null)return;
        new Thread(()->{
            try{
                String coords=current.getLongitude()+","+current.getLatitude()+";"+lon+","+lat;
                String url="https://router.project-osrm.org/route/v1/driving/"+coords+
                        "?overview=full&geometries=geojson&steps=true&alternatives=false&annotations=true";
                Request req=new Request.Builder().url(url).header("User-Agent","NicoGPS/6.0").get().build();
                try(Response res=http.newCall(req).execute()){
                    if(!res.isSuccessful()||res.body()==null) throw new IOException("HTTP "+res.code());
                    JsonObject root=JsonParser.parseString(res.body().string()).getAsJsonObject();
                    if(!"Ok".equals(root.get("code").getAsString())) throw new IOException(root.get("code").getAsString());
                    JsonObject route=root.getAsJsonArray("routes").get(0).getAsJsonObject();
                    JsonArray geom=route.getAsJsonObject("geometry").getAsJsonArray("coordinates");
                    ArrayList<GeoPoint> pts=new ArrayList<>();
                    for(JsonElement e:geom){JsonArray pt=e.getAsJsonArray();pts.add(new GeoPoint(pt.get(1).getAsDouble(),pt.get(0).getAsDouble()));}
                    double km=route.get("distance").getAsDouble()/1000.0; long min=Math.max(1,Math.round(route.get("duration").getAsDouble()/60.0));
                    ArrayList<Maneuver> ms=parseManeuvers(route,pts);
                    runOnUiThread(()->drawRoute(pts,km,min,ms));
                }
            }catch(Exception e){runOnUiThread(()->{status.setText("Itinéraire indisponible");Toast.makeText(this,"Itinéraire indisponible",Toast.LENGTH_LONG).show();});}
        }).start();
    }

    private ArrayList<Maneuver> parseManeuvers(JsonObject route, ArrayList<GeoPoint> pts){
        ArrayList<Maneuver> out=new ArrayList<>();
        JsonArray legs=route.getAsJsonArray("legs");
        if(legs==null) return out;
        for(JsonElement le:legs){
            JsonArray steps=le.getAsJsonObject().getAsJsonArray("steps"); if(steps==null) continue;
            for(JsonElement se:steps){
                JsonObject s=se.getAsJsonObject(); JsonObject m=s.getAsJsonObject("maneuver");
                if(m==null||!m.has("location")) continue;
                JsonArray loc=m.getAsJsonArray("location"); GeoPoint p=new GeoPoint(loc.get(1).getAsDouble(),loc.get(0).getAsDouble());
                String type=m.has("type")?m.get("type").getAsString():"";
                String mod=m.has("modifier")?m.get("modifier").getAsString():"";
                String name=s.has("name")?s.get("name").getAsString():"";
                String text=instruction(type,mod,name);
                double startDist=0; // recomputed approximately from route geometry index
                int idx=nearestIndex(pts,p); for(int i=0;i<idx && i<pts.size()-1;i++) startDist+=pts.get(i).distanceToAsDouble(pts.get(i+1));
                if(!"depart".equals(type)) out.add(new Maneuver(p,text,mod,startDist));
            }
        }
        return out;
    }

    private String instruction(String type,String mod,String name){
        if("arrive".equals(type)) return "Vous arrivez à destination";
        String road=name==null||name.isEmpty()?"":(" sur "+name);
        if("roundabout".equals(type)||"rotary".equals(type)) return "Prenez le rond-point"+road;
        if("exit roundabout".equals(type)) return "Sortez du rond-point"+road;
        if("uturn".equals(type)) return "Faites demi-tour"+road;
        if("merge".equals(type)) return "Rejoignez la voie"+road;
        if("fork".equals(type)) return ("left".equals(mod)?"Prenez la branche gauche":"Prenez la branche droite")+road;
        if("straight".equals(mod)||mod.isEmpty()) return "Continuez tout droit"+road;
        if(mod.contains("left")) return "Tournez à gauche"+road;
        if(mod.contains("right")) return "Tournez à droite"+road;
        return "Continuez"+road;
    }

    private void drawRoute(ArrayList<GeoPoint> pts,double km,long min,ArrayList<Maneuver> ms){
        if(routeLine!=null)map.getOverlays().remove(routeLine);
        if(routeCasing!=null)map.getOverlays().remove(routeCasing);
        routePoints.clear(); routePoints.addAll(pts); maneuvers.clear(); maneuvers.addAll(ms); nextManeuver=0;
        routeCasing=new Polyline(); routeCasing.setPoints(pts); routeCasing.setWidth(20f); routeCasing.setColor(0xFF263238); map.getOverlays().add(routeCasing);
        routeLine=new Polyline(); routeLine.setPoints(pts); routeLine.setWidth(11f); routeLine.setColor(0xFF00C7F2); map.getOverlays().add(routeLine);
        distance.setText(String.format(Locale.FRANCE,"%.1f km",km)); eta.setText(min+" min");
        routeActive=true; navigation3D=true; speedLimit=0; limitText.setText("Limite —");
        CarNavigationState.active=true; CarNavigationState.destination=lastDestinationTitle; CarNavigationState.etaMinutes=(int)min; CarNavigationState.remainingKm=km;
        acquireNavigationWakeLock();
        turnDistance.setText("Navigation prête"); turnText.setText(maneuvers.isEmpty()?"Suivez la ligne de route":maneuvers.get(0).text); turnIcon.setText(iconFor(maneuvers.isEmpty()?"":maneuvers.get(0).modifier)); roadName.setText(lastDestinationTitle.isEmpty()?"Navigation active":lastDestinationTitle); roadName.setVisibility(View.VISIBLE);
        status.setText("Navigation active"); map.invalidate(); speak("Itinéraire calculé. Navigation démarrée.");
    }

    private void updateNavigation(GeoPoint p,float speed){
        if(routePoints.isEmpty()) return;
        int nearest=nearestIndex(routePoints,p);
        double remaining=0;
        for(int i=nearest;i<routePoints.size()-1;i++) remaining+=routePoints.get(i).distanceToAsDouble(routePoints.get(i+1));

        while(nextManeuver<maneuvers.size()){
            int idx=nearestIndex(routePoints,maneuvers.get(nextManeuver).point);
            if(idx<=nearest+2){
                if(distanceTo(maneuvers.get(nextManeuver).point,p)<35){ nextManeuver++; continue; }
            }
            break;
        }

        if(nextManeuver<maneuvers.size()){
            Maneuver m=maneuvers.get(nextManeuver); double d=distanceTo(p,m.point);
            turnDistance.setText(formatDistance(d)); turnText.setText(m.text); turnIcon.setText(iconFor(m.modifier)); roadName.setText(extractRoadName(m.text));
            CarNavigationState.nextDistance=formatDistance(d); CarNavigationState.nextInstruction=m.text; CarNavigationState.remainingKm=remaining/1000.0;
            if(d<550) announceTurn(d,m.text);
        } else if(remaining<40){
            turnDistance.setText("Arrivée"); turnText.setText("Vous êtes arrivé à destination"); turnIcon.setText("✓");
        }

        if(speed>5 && distanceFromRoute(p,routePoints)>45 && System.currentTimeMillis()-lastReroute>15000){
            lastReroute=System.currentTimeMillis(); status.setText("Hors itinéraire • recalcul…");
            if(dest!=null) requestRoute(dest.getPosition().getLatitude(),dest.getPosition().getLongitude());
        }

        if(speedLimit>0 && speed>speedLimit+5){
            status.setText("⚠ Dépassement de la limite");
            if(!overspeedAnnounced){ speak("Attention, vous dépassez la limitation de vitesse."); overspeedAnnounced=true; }
        } else if(speedLimit==0 || speed<=speedLimit){ overspeedAnnounced=false; }
    }

    private void announceTurn(double d,String text){
        if(speaking) return;
        if(d<=500 || d<=200 || d<=80){
            String key="announce_"+nextManeuver+"_"+(d<=80?80:d<=200?200:500);
            if(getPreferences(MODE_PRIVATE).getBoolean(key,false)) return;
            getPreferences(MODE_PRIVATE).edit().putBoolean(key,true).apply();
            speak("Dans "+formatDistance(d)+", "+text);
        }
    }

    private void speak(String s){
        if(voiceMuted || tts==null) return; speaking=true;
        tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nicogps");
        map.postDelayed(()->speaking=false,Math.min(7000,Math.max(2000,s.length()*55L)));
    }

    private void lookupSpeedLimit(double lat,double lon){
        new Thread(()->{
            try{
                String q="[out:json][timeout:5];way(around:35,"+lat+","+lon+")[highway][maxspeed];out tags center;";
                String u="https://overpass-api.de/api/interpreter?data="+URLEncoder.encode(q,"UTF-8");
                Request req=new Request.Builder().url(u).header("User-Agent","NicoGPS/6.0").get().build();
                try(Response res=http.newCall(req).execute()){
                    if(!res.isSuccessful()||res.body()==null)return;
                    JsonArray el=JsonParser.parseString(res.body().string()).getAsJsonObject().getAsJsonArray("elements");
                    int limit=0;
                    for(JsonElement e:el){
                        JsonObject tags=e.getAsJsonObject().getAsJsonObject("tags"); if(tags==null||!tags.has("maxspeed"))continue;
                        String raw=tags.get("maxspeed").getAsString().replace(',','.');
                        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d{2,3})").matcher(raw);
                        if(m.find()){limit=Integer.parseInt(m.group(1));break;}
                    }
                    if(limit>0){ final int x=limit; runOnUiThread(()->{speedLimit=x;limitText.setText("Limite "+x);}); }
                }
            }catch(Exception ignored){}
        }).start();
    }

    private int nearestIndex(ArrayList<GeoPoint> pts,GeoPoint p){
        int best=0; double d=Double.MAX_VALUE;
        for(int i=0;i<pts.size();i++){double x=pts.get(i).distanceToAsDouble(p);if(x<d){d=x;best=i;}}
        return best;
    }

    private double distanceFromRoute(GeoPoint p,ArrayList<GeoPoint> pts){
        int idx=nearestIndex(pts,p); double best=pts.get(idx).distanceToAsDouble(p);
        if(idx>0) best=Math.min(best,pointSegmentDistance(p,pts.get(idx-1),pts.get(idx)));
        if(idx<pts.size()-1) best=Math.min(best,pointSegmentDistance(p,pts.get(idx),pts.get(idx+1)));
        return best;
    }

    private double pointSegmentDistance(GeoPoint p,GeoPoint a,GeoPoint b){
        double latScale=111320.0, lonScale=111320.0*Math.cos(Math.toRadians(p.getLatitude()));
        double px=p.getLongitude()*lonScale, py=p.getLatitude()*latScale;
        double ax=a.getLongitude()*lonScale, ay=a.getLatitude()*latScale, bx=b.getLongitude()*lonScale, by=b.getLatitude()*latScale;
        double dx=bx-ax,dy=by-ay,t=((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy); t=Math.max(0,Math.min(1,t));
        double x=ax+t*dx,y=ay+t*dy; return Math.hypot(px-x,py-y);
    }

    private double distanceTo(GeoPoint a,GeoPoint b){return a.distanceToAsDouble(b);}
    private String formatDistance(double d){return d<1000?Math.round(d)+" m":String.format(Locale.FRANCE,"%.1f km",d/1000.0);}
    private String iconFor(String mod){
        if(mod==null)return "➜"; if(mod.contains("left"))return "↰"; if(mod.contains("right"))return "↱"; if("uturn".equals(mod))return "↶"; return "↑";
    }

    private String extractRoadName(String instruction){
        if(instruction==null||instruction.trim().isEmpty()) return "Navigation active";
        int idx=instruction.indexOf(" sur ");
        if(idx>=0 && idx+5<instruction.length()) return instruction.substring(idx+5).trim();
        return instruction;
    }

    private void clearRoute(){
        releaseNavigationWakeLock();
        routeActive=false; routePoints.clear(); maneuvers.clear(); nextManeuver=0; speedLimit=0; CarNavigationState.active=false; CarNavigationState.nextDistance=""; CarNavigationState.nextInstruction="";
        if(routeLine!=null){map.getOverlays().remove(routeLine);routeLine=null;}
        if(routeCasing!=null){map.getOverlays().remove(routeCasing);routeCasing=null;}
        map.setMapOrientation(0f, true);
        if(dest!=null){map.getOverlays().remove(dest);dest=null;}
        turnCard.setVisibility(View.GONE); tripCard.setVisibility(View.VISIBLE); roadName.setText("Navigation active"); roadName.setVisibility(View.GONE); status.setText("GPS prêt"); map.invalidate();
    }

    private void initNavigationWakeLock(){
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        if(pm!=null){
            navigationWakeLock=pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK |
                    PowerManager.ACQUIRE_CAUSES_WAKEUP |
                    PowerManager.ON_AFTER_RELEASE,
                    "NicoGPS::NavigationScreen");
            navigationWakeLock.setReferenceCounted(false);
        }
    }

    private void acquireNavigationWakeLock(){
        if(navigationWakeLock!=null && !navigationWakeLock.isHeld()){
            try{ navigationWakeLock.acquire(); }catch(Exception ignored){}
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setKeepScreenOn(true);
        if(map!=null) map.setKeepScreenOn(true);
    }

    private void releaseNavigationWakeLock(){
        if(navigationWakeLock!=null && navigationWakeLock.isHeld()){
            try{ navigationWakeLock.release(); }catch(Exception ignored){}
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setKeepScreenOn(false);
        if(map!=null) map.setKeepScreenOn(false);
    }

    private void saveCurrentFavorite(){
        if(dest==null || dest.getPosition()==null){ Toast.makeText(this,"Aucune destination à enregistrer",Toast.LENGTH_SHORT).show(); return; }
        String name=dest.getTitle()==null||dest.getTitle().trim().isEmpty()?"Destination":dest.getTitle();
        android.content.SharedPreferences p=getSharedPreferences("favorites",MODE_PRIVATE);
        JsonArray a; try{ a=p.contains("items")?JsonParser.parseString(p.getString("items","[]")).getAsJsonArray():new JsonArray(); }catch(Exception e){a=new JsonArray();}
        JsonObject o=new JsonObject(); o.addProperty("name",name); o.addProperty("lat",dest.getPosition().getLatitude()); o.addProperty("lon",dest.getPosition().getLongitude());
        boolean exists=false; for(JsonElement e:a){JsonObject x=e.getAsJsonObject(); if(Math.abs(x.get("lat").getAsDouble()-dest.getPosition().getLatitude())<0.0003 && Math.abs(x.get("lon").getAsDouble()-dest.getPosition().getLongitude())<0.0003){exists=true;break;}}
        if(!exists){a.add(o);p.edit().putString("items",a.toString()).apply(); Toast.makeText(this,"⭐ Destination enregistrée",Toast.LENGTH_SHORT).show();}
        else Toast.makeText(this,"Déjà dans les favoris",Toast.LENGTH_SHORT).show();
    }

    private void showFavorites(){
        android.content.SharedPreferences p=getSharedPreferences("favorites",MODE_PRIVATE); JsonArray a;
        try{a=JsonParser.parseString(p.getString("items","[]")).getAsJsonArray();}catch(Exception e){a=new JsonArray();}
        if(a.size()==0){new AlertDialog.Builder(this).setTitle("⭐ Favoris").setMessage("Aucune destination enregistrée.").setPositiveButton("OK",null).show();return;}
        String[] names=new String[a.size()]; for(int i=0;i<a.size();i++)names[i]=a.get(i).getAsJsonObject().get("name").getAsString();
        final JsonArray favorites=a;
        new AlertDialog.Builder(this).setTitle("⭐ Favoris").setItems(names,(d,which)->{JsonObject o=favorites.get(which).getAsJsonObject(); setDestination(o.get("lat").getAsDouble(),o.get("lon").getAsDouble(),o.get("name").getAsString());}).setNegativeButton("Fermer",null).setNeutralButton("Gérer",(d,w)->manageFavorites()).show();
    }

    private void manageFavorites(){
        android.content.SharedPreferences p=getSharedPreferences("favorites",MODE_PRIVATE); JsonArray a;
        try{a=JsonParser.parseString(p.getString("items","[]")).getAsJsonArray();}catch(Exception e){a=new JsonArray();}
        if(a.size()==0){showFavorites();return;}
        String[] names=new String[a.size()]; for(int i=0;i<a.size();i++)names[i]="🗑 "+a.get(i).getAsJsonObject().get("name").getAsString();
        final JsonArray favorites=a;
        new AlertDialog.Builder(this).setTitle("Supprimer un favori").setItems(names,(d,which)->{favorites.remove(which);p.edit().putString("items",favorites.toString()).apply();Toast.makeText(this,"Favori supprimé",Toast.LENGTH_SHORT).show();}).setNegativeButton("Fermer",null).show();
    }

    private void settings(){new AlertDialog.Builder(this).setTitle("NicoGPS 6.0")
            .setMessage("Navigation GPS avancée\n\n- Position et suivi automatique\n- Flèche orientée selon le déplacement\n- Vue conduite pseudo-3D orientée dans le sens de la route\n- Centrage avancé avec route visible devant\n- Itinéraire OSRM + instructions virage par virage\n- Recalcul automatique si sortie d’itinéraire\n- Guidage vocal\n- Vitesse et tentative de limitation OSM\n- Alerte de dépassement\n- Recherche d’adresse avec secours OpenStreetMap\n\nLes limitations et données routières peuvent être absentes selon les données OpenStreetMap disponibles.")
            .setPositiveButton("OK",null).show();}


    @Override protected void onResume() {
        super.onResume();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setKeepScreenOn(true);
        if (map != null) map.setKeepScreenOn(true);
        if(routeActive) acquireNavigationWakeLock();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            getWindow().getDecorView().setKeepScreenOn(true);
            if (map != null) map.setKeepScreenOn(true);
            if(routeActive) acquireNavigationWakeLock();
        }
    }

    @Override protected void onDestroy(){
        releaseNavigationWakeLock();
        if(fused!=null&&locationCallback!=null)fused.removeLocationUpdates(locationCallback);
        if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy();
    }
}
