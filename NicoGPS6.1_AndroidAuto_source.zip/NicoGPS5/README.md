# NicoGPS 6.1

Version finale de travail de NicoGPS : navigation routière, suivi GPS, guidage vocal, vue conduite pseudo-3D, écran maintenu actif, recherche par loupe, destinations favorites et compatibilité Android Auto via Android for Cars.

La partie Android Auto utilise le modèle de navigation officiel `CarAppService` / `NavigationTemplate`. La carte du téléphone et la session voiture sont séparées par l’architecture Android for Cars.


## Android Auto 6.1

- Car App Library 1.7.0
- Android Auto projected artifact
- CarAppService déclaré comme application de navigation
- NavigationManager : démarrage/arrêt de navigation et rafraîchissement de l'interface
- NavigationTemplate avec ETA et distance partagées avec l'écran téléphone
- Surface Android Auto avec route stylisée, instruction et vitesse
