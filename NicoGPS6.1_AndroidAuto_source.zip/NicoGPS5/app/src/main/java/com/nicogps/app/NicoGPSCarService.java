package com.nicogps.app;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.Surface;

import androidx.annotation.NonNull;
import androidx.car.app.AppManager;
import androidx.car.app.CarAppService;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.Session;
import androidx.car.app.SurfaceCallback;
import androidx.car.app.SurfaceContainer;
import androidx.car.app.navigation.NavigationManager;
import androidx.car.app.navigation.NavigationManagerCallback;
import androidx.car.app.navigation.model.NavigationTemplate;
import androidx.car.app.model.Action;
import androidx.car.app.model.ActionStrip;
import androidx.car.app.model.CarColor;
import androidx.car.app.model.DateTimeWithZone;
import androidx.car.app.model.Distance;
import androidx.car.app.navigation.model.TravelEstimate;
import androidx.car.app.validation.HostValidator;

import java.util.TimeZone;

public class NicoGPSCarService extends CarAppService {
    @NonNull
    @Override
    public HostValidator createHostValidator() {
        return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR;
    }

    @NonNull
    @Override
    public Session onCreateSession() {
        return new Session() {
            @NonNull
            @Override
            public Screen onCreateScreen(@NonNull Intent intent) {
                return new CarScreen(getCarContext());
            }
        };
    }

    private static class CarScreen extends Screen {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final NavigationManager navigationManager;
        private boolean carNavigationStarted = false;
        private Surface lastSurface;

        private final Runnable refresh = new Runnable() {
            @Override public void run() {
                syncNavigationState();
                invalidate();
                drawLastSurface();
                handler.postDelayed(this, 1000);
            }
        };

        CarScreen(CarContext context) {
            super(context);
            navigationManager = context.getCarService(NavigationManager.class);

            navigationManager.setNavigationManagerCallback(new NavigationManagerCallback() {
                @Override public void onStopNavigation() {
                    CarNavigationState.active = false;
                    carNavigationStarted = false;
                    invalidate();
                }

                @Override public void onAutoDriveEnabled() {
                    // Le mode simulation est destiné aux tests Android Auto/DHU.
                    invalidate();
                }
            });

            context.getCarService(AppManager.class).setSurfaceCallback(new SurfaceCallback() {
                @Override public void onSurfaceAvailable(@NonNull SurfaceContainer sc) {
                    lastSurface = sc.getSurface();
                    draw(sc);
                }

                @Override public void onSurfaceDestroyed(@NonNull SurfaceContainer sc) {
                    if (lastSurface == sc.getSurface()) lastSurface = null;
                }

                @Override public void onStableAreaChanged(@NonNull Rect r) {
                    drawLastSurface();
                }
            });

            handler.post(refresh);
        }

        private void syncNavigationState() {
            boolean active = CarNavigationState.active;
            if (active && !carNavigationStarted) {
                try {
                    navigationManager.navigationStarted();
                    carNavigationStarted = true;
                } catch (Exception ignored) {}
            } else if (!active && carNavigationStarted) {
                try {
                    navigationManager.navigationEnded();
                } catch (Exception ignored) {}
                carNavigationStarted = false;
            }
        }

        private void drawLastSurface() {
            if (lastSurface == null) return;
            Canvas c = null;
            try {
                c = lastSurface.lockCanvas(null);
                if (c == null) return;
                drawCanvas(c);
            } finally {
                if (c != null) lastSurface.unlockCanvasAndPost(c);
            }
        }

        private void draw(SurfaceContainer sc) {
            Surface s = sc.getSurface();
            if (s == null) return;
            Canvas c = null;
            try {
                c = s.lockCanvas(null);
                if (c == null) return;
                drawCanvas(c);
            } finally {
                if (c != null) s.unlockCanvasAndPost(c);
            }
        }

        private void drawCanvas(Canvas c) {
            float w = c.getWidth();
            float h = c.getHeight();

            c.drawColor(0xFF101820);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(10f, w * 0.018f));
            paint.setColor(0xFF202124);
            c.drawLine(w * .50f, h, w * .50f, h * .58f, paint);
            c.drawLine(w * .50f, h * .58f, w * .64f, h * .30f, paint);

            paint.setStrokeWidth(Math.max(6f, w * 0.010f));
            paint.setColor(0xFF4285F4);
            c.drawLine(w * .50f, h, w * .50f, h * .58f, paint);
            c.drawLine(w * .50f, h * .58f, w * .64f, h * .30f, paint);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFFFFFFFF);
            float x = w * .50f, y = h * .72f;
            c.save();
            c.rotate(0, x, y);
            c.drawCircle(x, y, Math.max(14f, w * .025f), paint);
            c.restore();

            paint.setTextAlign(Paint.Align.LEFT);
            paint.setTextSize(Math.max(22f, w * .035f));
            paint.setColor(0xFFFFFFFF);
            String instruction = CarNavigationState.nextInstruction;
            if (instruction == null || instruction.isEmpty()) instruction = "Navigation NicoGPS";
            c.drawText(instruction, w * .04f, h * .10f, paint);

            paint.setTextSize(Math.max(20f, w * .030f));
            String distance = CarNavigationState.nextDistance;
            if (distance == null || distance.isEmpty()) distance = "";
            c.drawText(distance, w * .04f, h * .15f, paint);

            paint.setTextAlign(Paint.Align.RIGHT);
            String speed = String.format(java.util.Locale.FRANCE, "%.0f km/h", CarNavigationState.speedKmh);
            c.drawText(speed, w * .96f, h * .92f, paint);
        }

        @NonNull
        @Override
        public androidx.car.app.model.Template onGetTemplate() {
            long etaMillis = System.currentTimeMillis()
                    + (long) Math.max(0, CarNavigationState.etaMinutes) * 60_000L;

            double km = Math.max(0.0, CarNavigationState.remainingKm);
            TravelEstimate estimate = new TravelEstimate.Builder(
                    Distance.create(km, Distance.UNIT_KILOMETERS),
                    DateTimeWithZone.create(etaMillis, TimeZone.getDefault())
            ).build();

            ActionStrip strip = new ActionStrip.Builder()
                    .addAction(new Action.Builder(Action.PAN)
                            .setTitle("Carte")
                            .build())
                    .build();

            return new NavigationTemplate.Builder()
                    .setBackgroundColor(CarColor.SECONDARY)
                    .setActionStrip(strip)
                    .setDestinationTravelEstimate(estimate)
                    .build();
        }

        @Override
        public void onStop() {
            handler.removeCallbacks(refresh);
            try {
                if (carNavigationStarted) navigationManager.navigationEnded();
            } catch (Exception ignored) {}
            carNavigationStarted = false;
            super.onStop();
        }
    }
}
