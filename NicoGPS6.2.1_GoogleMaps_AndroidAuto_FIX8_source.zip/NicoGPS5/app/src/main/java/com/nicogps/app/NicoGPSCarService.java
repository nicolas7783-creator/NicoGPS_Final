package com.nicogps.app;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.Surface;

import androidx.annotation.NonNull;
import androidx.car.app.AppManager;
import androidx.car.app.CarAppService;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.Session;
import androidx.car.app.SurfaceCallback;
import androidx.car.app.SurfaceContainer;
import androidx.car.app.model.Action;
import androidx.car.app.model.ActionStrip;
import androidx.car.app.model.CarColor;
import androidx.car.app.navigation.NavigationManager;
import androidx.car.app.navigation.NavigationManagerCallback;
import androidx.car.app.navigation.model.NavigationTemplate;
import androidx.car.app.navigation.model.TravelEstimate;
import androidx.car.app.model.DateTimeWithZone;
import androidx.car.app.model.Distance;
import androidx.car.app.validation.HostValidator;

import java.util.TimeZone;

public class NicoGPSCarService extends CarAppService {

    @NonNull
    @Override
    public HostValidator createHostValidator() {
        // Debug/sideload testing: allow the Android Auto host to connect.
        return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR;
    }

    @NonNull
    @Override
    public Session onCreateSession() {
        return new Session() {
            @NonNull
            @Override
            public Screen onCreateScreen(@NonNull Intent intent) {
                return new CarScreen(getCarContext());
            }
        };
    }

    private static class CarScreen extends Screen {

        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final NavigationManager navigationManager;
        private boolean navigationStarted = false;

        CarScreen(@NonNull CarContext carContext) {
            super(carContext);

            navigationManager =
                    carContext.getCarService(NavigationManager.class);

            navigationManager.setNavigationManagerCallback(
                    new NavigationManagerCallback() {
                        @Override
                        public void onStopNavigation() {
                            CarNavigationState.active = false;
                            navigationStarted = false;
                            invalidate();
                        }
                    });

            carContext.getCarService(AppManager.class)
                    .setSurfaceCallback(new SurfaceCallback() {

                        @Override
                        public void onSurfaceAvailable(
                                @NonNull SurfaceContainer surfaceContainer) {
                            draw(surfaceContainer);
                        }

                        @Override
                        public void onSurfaceDestroyed(
                                @NonNull SurfaceContainer surfaceContainer) {
                        }

                        @Override
                        public void onStableAreaChanged(@NonNull Rect stableArea) {
                        }

                        @Override
                        public void onVisibleAreaChanged(@NonNull Rect visibleArea) {
                        }
                    });
        }

        private void draw(@NonNull SurfaceContainer container) {
            Surface surface = container.getSurface();
            if (surface == null || !surface.isValid()) {
                return;
            }

            Canvas canvas = null;

            try {
                canvas = surface.lockCanvas(null);
                if (canvas == null) {
                    return;
                }

                canvas.drawColor(0xFF101820);

                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(18f);
                paint.setColor(0xFF2B78E4);

                float cx = canvas.getWidth() / 2f;

                canvas.drawLine(
                        cx,
                        canvas.getHeight(),
                        cx,
                        canvas.getHeight() * 0.58f,
                        paint
                );

                canvas.drawLine(
                        cx,
                        canvas.getHeight() * 0.58f,
                        canvas.getWidth() * 0.62f,
                        canvas.getHeight() * 0.30f,
                        paint
                );

                paint.setStyle(Paint.Style.FILL);
                paint.setColor(0xFFFFFFFF);

                canvas.drawCircle(
                        cx,
                        canvas.getHeight() * 0.72f,
                        18f,
                        paint
                );

            } finally {
                if (canvas != null) {
                    surface.unlockCanvasAndPost(canvas);
                }
            }
        }

        @NonNull
        @Override
        public androidx.car.app.model.Template onGetTemplate() {

            if (CarNavigationState.active && !navigationStarted) {
                navigationManager.navigationStarted();
                navigationStarted = true;
            }

            if (!CarNavigationState.active && navigationStarted) {
                navigationManager.navigationEnded();
                navigationStarted = false;
            }

            ActionStrip strip =
                    new ActionStrip.Builder()
                            .addAction(
                                    new Action.Builder(Action.PAN)
                                            .setTitle("Carte")
                                            .build()
                            )
                            .build();

            String destination =
                    CarNavigationState.destination == null ||
                    CarNavigationState.destination.trim().isEmpty()
                            ? "NicoGPS"
                            : CarNavigationState.destination;

            String instruction =
                    CarNavigationState.nextInstruction == null ||
                    CarNavigationState.nextInstruction.trim().isEmpty()
                            ? "Navigation prête"
                            : CarNavigationState.nextInstruction;

            long remainingSeconds =
                    Math.max(60L, CarNavigationState.etaMinutes * 60L);

            double remainingMeters =
                    Math.max(0.0, CarNavigationState.remainingKm * 1000.0);

            TravelEstimate estimate =
                    new TravelEstimate.Builder(
                            Distance.create(
                                    remainingMeters,
                                    Distance.UNIT_METERS
                            ),
                            DateTimeWithZone.create(
                                    System.currentTimeMillis(),
                                    TimeZone.getDefault()
                            )
                    )
                    .setRemainingTimeSeconds(remainingSeconds)
                    .build();

            return new NavigationTemplate.Builder()
                    .setBackgroundColor(CarColor.SECONDARY)
                    .setActionStrip(strip)
                    .setDestinationTravelEstimate(estimate)
                    .build();
        }
    }
}
