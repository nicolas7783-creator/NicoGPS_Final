# NicoGPS 6.2.1 – Google Maps + Android Auto

Base source preserved from the working NicoGPS 6.2.1 Google Maps project.

FIX8 changes:
- preserves the Google Maps MainActivity and navigation UI;
- keeps the existing search-result deduplication;
- keeps the screen-awake/navigation wake-lock logic;
- Android Auto uses Car App Library 1.7.0 + app-projected;
- Android Auto navigation service uses ALLOW_ALL_HOSTS_VALIDATOR for sideload/debug testing;
- Android Auto manifest discovery is kept explicit;
- phone screen orientation is sensor-based;
- CarAppActivity launcher entry is removed because this build targets Android Auto projection;
- an explicit NicoGPS navigation icon is declared.

This is a source project for rebuilding through GitHub Actions.
