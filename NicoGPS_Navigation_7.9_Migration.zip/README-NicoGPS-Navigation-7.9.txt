NicoGPS — workflow de migration vers Google Navigation SDK 7.9.0

Le workflow sélectionne automatiquement un ZIP 6.2.1 du dépôt, retire la dépendance
directe Google Maps SDK, ajoute Navigation SDK 7.9.0, configure AndroidX/Java 17,
le desugaring, la clé API et compile l'APK debug avec publication en artifact.

Il est basé sur la documentation Google actuelle. Le premier vrai test sera exécuté
par GitHub Actions dans ton dépôt ; je ne prétends pas que l'APK est déjà compilé.
