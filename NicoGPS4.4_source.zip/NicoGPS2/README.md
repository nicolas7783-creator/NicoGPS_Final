# NicoGPS 4.4

Application Android de navigation avec mode conduite avancé.

Fonctions incluses :
- position GPS réelle et suivi de position
- carte OpenStreetMap via osmdroid
- recherche de destination
- calcul d'itinéraire routier via OSRM, sans clé OpenRouteService
- tracé de l'itinéraire sur la carte
- distance et durée estimées
- synthèse vocale à la création de l'itinéraire
- bouton de recentrage

## Compilation GitHub Actions
Le projet contient son propre workflow dans `.github/workflows/build.yml`.
Il peut être lancé manuellement depuis Actions et se lance aussi après un push sur `main`.

Le workflow utilise Java 17 et Gradle 8.11.1.

- mode conduite pseudo-3D, cap conservé à très basse vitesse et écran maintenu allumé pendant la navigation : carte orientée dans le sens du déplacement
- centrage avancé : position du véhicule placée plus bas pour voir la route devant
- bouton 2D/3D pour changer de vue
- tracé routier avec contour pour une meilleure lisibilité


## 4.4
- Maintien d’écran renforcé pendant la navigation : FLAG_KEEP_SCREEN_ON + WakeLock écran actif.
- Le verrou est acquis au démarrage d’un itinéraire et libéré à l’arrêt de la navigation.
- Retour au premier plan : le maintien est réactivé si une navigation est active.
